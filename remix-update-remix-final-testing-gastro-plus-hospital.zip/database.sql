-- Supabase SQL Schema for Hospital Management System
-- Run this in your Supabase SQL Editor
--
-- === MIGRATION/UPDATE FOR INSTALLED DATABASES ===
-- If you already ran this schema previously, please execute the following statements to update patients, invoices, profiles and staff tables:
-- ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS attending_doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
-- ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS payment_reference TEXT;
-- ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS payment_remarks TEXT;
-- ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS consultation_fee DECIMAL(10, 2) DEFAULT 0.00;
-- ALTER TABLE public.staff ADD COLUMN IF NOT EXISTS consultation_fee DECIMAL(10, 2) DEFAULT 0.00;
-- ===============================================

-- 1. Profiles / Users (Optional reference to auth.users handled manually without FK block constraint)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'SURGEON', 'NURSE', 'RECEPTIONIST', 'ACCOUNTANT', 'LAB_TECHNICIAN', 'PHARMACIST')),
  department TEXT,
  designation TEXT,
  phone TEXT,
  degree TEXT,
  specialization TEXT,
  avatar_url TEXT,
  status TEXT DEFAULT 'ACTIVE',
  consultation_fee DECIMAL(10, 2) DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Drop the foreign key constraint if it exists to allow inserting staff/profiles seamlessly from the client side
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

-- 1.1 Staff (Dedicated table for staff employee records synchronized with profiles)
CREATE TABLE IF NOT EXISTS public.staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL,
  department TEXT,
  designation TEXT,
  phone TEXT,
  degree TEXT,
  specialization TEXT,
  avatar_url TEXT,
  status TEXT DEFAULT 'ACTIVE',
  consultation_fee DECIMAL(10, 2) DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Functions and Triggers to synchronize profiles and staff bidirectionally
CREATE OR REPLACE FUNCTION public.sync_profiles_to_staff()
RETURNS TRIGGER AS $$
BEGIN
  IF pg_trigger_depth() > 1 THEN
    RETURN NEW;
  END IF;
  
  INSERT INTO public.staff (id, name, email, role, department, designation, phone, degree, specialization, avatar_url, status, consultation_fee, created_at, updated_at)
  VALUES (NEW.id, NEW.name, NEW.email, NEW.role, NEW.department, NEW.designation, NEW.phone, NEW.degree, NEW.specialization, NEW.avatar_url, NEW.status, NEW.consultation_fee, NEW.created_at, NEW.updated_at)
  ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    email = EXCLUDED.email,
    role = EXCLUDED.role,
    department = EXCLUDED.department,
    designation = EXCLUDED.designation,
    phone = EXCLUDED.phone,
    degree = EXCLUDED.degree,
    specialization = EXCLUDED.specialization,
    avatar_url = EXCLUDED.avatar_url,
    status = EXCLUDED.status,
    consultation_fee = EXCLUDED.consultation_fee,
    updated_at = EXCLUDED.updated_at;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS sync_profiles_to_staff_trigger ON public.profiles;
CREATE TRIGGER sync_profiles_to_staff_trigger
AFTER INSERT OR UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.sync_profiles_to_staff();

-- Revoke execute from public roles as it is not meant to be callable by users
REVOKE EXECUTE ON FUNCTION public.sync_profiles_to_staff() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.sync_staff_to_profiles()
RETURNS TRIGGER AS $$
BEGIN
  IF pg_trigger_depth() > 1 THEN
    RETURN NEW;
  END IF;

  BEGIN
    INSERT INTO public.profiles (id, name, email, role, department, designation, phone, degree, specialization, avatar_url, status, consultation_fee, created_at, updated_at)
    VALUES (NEW.id, NEW.name, NEW.email, NEW.role, NEW.department, NEW.designation, NEW.phone, NEW.degree, NEW.specialization, NEW.avatar_url, NEW.status, NEW.consultation_fee, NEW.created_at, NEW.updated_at)
    ON CONFLICT (id) DO UPDATE SET
      name = EXCLUDED.name,
      email = EXCLUDED.email,
      role = EXCLUDED.role,
      department = EXCLUDED.department,
      designation = EXCLUDED.designation,
      phone = EXCLUDED.phone,
      degree = EXCLUDED.degree,
      specialization = EXCLUDED.specialization,
      avatar_url = EXCLUDED.avatar_url,
      status = EXCLUDED.status,
      consultation_fee = EXCLUDED.consultation_fee,
      updated_at = EXCLUDED.updated_at;
  EXCEPTION
    WHEN OTHERS THEN
      -- Handle gracefully if profiles table constraint (e.g. auth.users reference) throws an error
      NULL;
  END;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS sync_staff_to_profiles_trigger ON public.staff;
CREATE TRIGGER sync_staff_to_profiles_trigger
AFTER INSERT OR UPDATE ON public.staff
FOR EACH ROW EXECUTE FUNCTION public.sync_staff_to_profiles();

-- Revoke execute from public roles as it is not meant to be callable by users
REVOKE EXECUTE ON FUNCTION public.sync_staff_to_profiles() FROM PUBLIC, anon, authenticated;

-- Sync deletes
CREATE OR REPLACE FUNCTION public.sync_profiles_to_staff_delete()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM public.staff WHERE id = OLD.id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS sync_profiles_to_staff_delete_trigger ON public.profiles;
CREATE TRIGGER sync_profiles_to_staff_delete_trigger
AFTER DELETE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.sync_profiles_to_staff_delete();

-- Revoke execute from public roles as it is not meant to be callable by users
REVOKE EXECUTE ON FUNCTION public.sync_profiles_to_staff_delete() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.sync_staff_to_profiles_delete()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM public.profiles WHERE id = OLD.id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS sync_staff_to_profiles_delete_trigger ON public.staff;
CREATE TRIGGER sync_staff_to_profiles_delete_trigger
AFTER DELETE ON public.staff
FOR EACH ROW EXECUTE FUNCTION public.sync_staff_to_profiles_delete();

-- Revoke execute from public roles as it is not meant to be callable by users
REVOKE EXECUTE ON FUNCTION public.sync_staff_to_profiles_delete() FROM PUBLIC, anon, authenticated;

-- 2. Hospital Information
CREATE TABLE IF NOT EXISTS public.hospital_info (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  logo_url TEXT,
  tagline TEXT,
  registration_number TEXT,
  tax_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2.0.1 Tax Slabs & GST Configuration
CREATE TABLE IF NOT EXISTS public.tax_slabs (
  id TEXT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  rate NUMERIC(5,2) NOT NULL DEFAULT 0.00,
  type VARCHAR(50) NOT NULL DEFAULT 'GST',
  description TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed defaults standard GST Slabs
INSERT INTO public.tax_slabs (id, name, rate, type, description, is_active) VALUES
('tax-ex', 'GST Zero (Exempt)', 0.00, 'GST', 'Medical services and select life-saving medicines', true),
('tax-5', 'GST 5%', 5.00, 'GST', 'Standard pharmaceutical drugs, injectables, and diagnostic test kits', true),
('tax-12', 'GST 12%', 12.00, 'GST', 'Syringes, medical instruments, and specialised diabetic medicines', true),
('tax-18', 'GST 18%', 18.00, 'GST', 'Capital healthcare machinery, monitors, and dental care fixtures', true),
('tax-28', 'GST 28%', 28.00, 'GST', 'Aesthetic improvements and luxury cosmetic treatments', true)
ON CONFLICT (id) DO NOTHING;

-- 2.0.2 IPD Bed Rates Configuration
CREATE TABLE IF NOT EXISTS public.bed_rates (
  type VARCHAR(100) PRIMARY KEY,
  rate NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.bed_rates (type, rate) VALUES
('General', 1500.00),
('Semi-Private', 3000.00),
('Private', 5000.00),
('ICU', 8000.00),
('Maternity', 4000.00)
ON CONFLICT (type) DO NOTHING;

-- 2.0.3 OT Rates Configuration
CREATE TABLE IF NOT EXISTS public.ot_rates (
  type VARCHAR(100) PRIMARY KEY,
  rate NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.ot_rates (type, rate) VALUES
('Minor', 5000.00),
('Major', 15000.00),
('Cardiac', 45000.00),
('Neuro', 55000.00)
ON CONFLICT (type) DO NOTHING;

-- 2.0.4 Material Rates Configuration
CREATE TABLE IF NOT EXISTS public.material_rates (
  name VARCHAR(255) PRIMARY KEY,
  price NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  category VARCHAR(100) NOT NULL DEFAULT 'Disposable',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.material_rates (name, price, category) VALUES
('Surgical Gloves', 150.00, 'Disposable'),
('Syringes (Pack of 10)', 100.00, 'Disposable'),
('IV Fluid Set', 450.00, 'Disposable'),
('Cotton / Bandage Kit', 200.00, 'Material'),
('Disinfectant Solution', 350.00, 'Material'),
('Catheter Set', 850.00, 'Disposable')
ON CONFLICT (name) DO NOTHING;

-- 2.0.5 OPD consultation and registration charges Configuration
CREATE TABLE IF NOT EXISTS public.opd_charges (
  key VARCHAR(50) PRIMARY KEY,
  value NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.opd_charges (key, value) VALUES
('reg', 200.00),
('appt', 200.00),
('consult', 500.00)
ON CONFLICT (key) DO NOTHING;

-- 2.1 Pharmacy & Billing Settings
CREATE TABLE IF NOT EXISTS public.pharmacy_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  logo_url TEXT,
  pharmacy_name TEXT,
  address TEXT,
  phone TEXT,
  tagline TEXT,
  gstin TEXT,
  bank_name TEXT,
  bank_branch TEXT,
  bank_acc_no TEXT,
  bank_ifsc TEXT,
  upi_id TEXT,
  terms_and_conditions TEXT[] DEFAULT ARRAY[
    'Subject to Maharashtra Jurisdiction.',
    'Our Responsibility Ceases as soon as goods leave our Premises.',
    'Goods once sold will not be taken back.',
    'Delivery Ex-Premises.'
  ],
  additional_footer TEXT DEFAULT 'Thanks for your order! We look forward to working with you again soon.',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Departments
CREATE TABLE IF NOT EXISTS public.departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  head_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.1 Specialties
CREATE TABLE IF NOT EXISTS public.specialties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Patients
CREATE TABLE IF NOT EXISTS public.patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mrn TEXT UNIQUE NOT NULL, 
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  dob DATE,
  age INTEGER,
  gender TEXT,
  blood_group TEXT,
  address TEXT,
  guardian_name TEXT,
  mother_name TEXT,
  mother_phone TEXT,
  father_name TEXT,
  father_phone TEXT,
  husband_name TEXT,
  husband_phone TEXT,
  tpa_id TEXT,
  tpa_validity DATE,
  status TEXT DEFAULT 'Active',
  registration_type TEXT DEFAULT 'OPD',
  needs_admission BOOLEAN DEFAULT FALSE,
  attending_doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  is_referral BOOLEAN DEFAULT FALSE,
  referred_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Beds & Wards
CREATE TABLE IF NOT EXISTS public.beds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bed_number TEXT NOT NULL,
  ward TEXT NOT NULL,
  bed_type TEXT NOT NULL,
  status TEXT DEFAULT 'Available',
  daily_rate DECIMAL(10, 2) DEFAULT 0.00,
  patient_id UUID REFERENCES public.patients(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Appointments (OPD)
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  token_number INTEGER,
  urgency TEXT DEFAULT 'Routine',
  status TEXT DEFAULT 'Scheduled',
  fee DECIMAL(10, 2) DEFAULT 0.00,
  payment_status TEXT DEFAULT 'Pending',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6.1 Quick Registrations (Maintains separate database table for Quick Patient Registrations)
CREATE TABLE IF NOT EXISTS public.quick_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mrn TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT,
  age INTEGER,
  gender TEXT,
  facility TEXT DEFAULT 'OPD', -- OPD, Lab, Pharmacy, Radiology, Emergency
  status TEXT DEFAULT 'Active',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6.2 Live Queue (Maintains separate database table for the Live Consultation Queue)
CREATE TABLE IF NOT EXISTS public.live_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_number INTEGER,
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  appointment_id UUID REFERENCES public.appointments(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'Waiting', -- Waiting, In-Consultation, Completed, Absent
  urgency TEXT DEFAULT 'Routine',
  check_in_time TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. IPD Admissions
CREATE TABLE IF NOT EXISTS public.admissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  bed_id UUID REFERENCES public.beds(id),
  doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  admission_date TIMESTAMPTZ DEFAULT NOW(),
  discharge_date TIMESTAMPTZ,
  reason TEXT,
  initial_deposit DECIMAL(10, 2) DEFAULT 0.00,
  status TEXT DEFAULT 'Admitted',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Clinical Notes & Vitals
CREATE TABLE IF NOT EXISTS public.patient_vitals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  recorded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  temperature DECIMAL(5, 2),
  blood_pressure TEXT,
  pulse INTEGER,
  respiration INTEGER,
  spo2 INTEGER,
  weight DECIMAL(5, 2),
  recorded_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.clinical_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  author_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  note_type TEXT CHECK (note_type IN ('DOCTOR', 'NURSE')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8.1 Prescriptions
CREATE TABLE IF NOT EXISTS public.prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  doctor_name TEXT,
  prescription_date TIMESTAMPTZ DEFAULT NOW(),
  diagnosis TEXT,
  advice TEXT,
  medicines JSONB DEFAULT '[]'::jsonb,
  medications JSONB DEFAULT '[]'::jsonb,
  attachment_url TEXT,
  attachment_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Investigations & Lab Tests
CREATE TABLE IF NOT EXISTS public.lab_tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT, 
  price DECIMAL(10, 2) DEFAULT 0.00,
  department_id UUID REFERENCES public.departments(id)
);

CREATE TABLE IF NOT EXISTS public.test_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  test_id UUID REFERENCES public.lab_tests(id),
  requested_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'Pending',
  results JSONB,
  report_url TEXT,
  requested_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

-- 10. Pharmacy Inventory
CREATE TABLE IF NOT EXISTS public.pharmacy_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  generic_name TEXT,
  category TEXT,
  stock_quantity INTEGER DEFAULT 0,
  reorder_level INTEGER DEFAULT 10,
  min_stock_level INTEGER DEFAULT 10, -- Alias for UI consistency
  unit TEXT, -- e.g., 'Tablets', 'Bottle'
  expiry_date DATE,
  purchase_price DECIMAL(10, 2),
  sale_price DECIMAL(10, 2),
  mrp DECIMAL(10, 2),
  tax_percentage DECIMAL(5, 2) DEFAULT 0.00,
  hsn_code TEXT,
  batch_number TEXT,
  rack_number TEXT,
  manufacturer TEXT,
  composition TEXT, -- e.g., 'Amoxicillin + Clavulanic Acid'
  is_loose_sale_enabled BOOLEAN DEFAULT FALSE,
  units_per_strip INTEGER DEFAULT 10,
  loose_selling_price DECIMAL(10, 2) DEFAULT 0.00,
  loose_stock INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10.1 Pharmacy Purchases (Tracking Stock Inflow)
CREATE TABLE IF NOT EXISTS public.pharmacy_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID REFERENCES public.pharmacy_items(id),
  supplier_name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  purchase_price DECIMAL(10, 2) NOT NULL,
  expiry_date DATE,
  invoice_number TEXT,
  recorded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.inventory_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID REFERENCES public.pharmacy_items(id),
  transaction_type TEXT CHECK (transaction_type IN ('PURCHASE', 'SALE', 'ADJUSTMENT', 'EXPIRED')),
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10, 2),
  total_price DECIMAL(10, 2),
  reference_id TEXT,
  performed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Billing & Invoices
CREATE TABLE IF NOT EXISTS public.invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  invoice_number TEXT UNIQUE NOT NULL,
  total_amount DECIMAL(10, 2) NOT NULL,
  discount_amount DECIMAL(10, 2) DEFAULT 0.00,
  tax_amount DECIMAL(10, 2) DEFAULT 0.00,
  payable_amount DECIMAL(10, 2) NOT NULL,
  paid_amount DECIMAL(10, 2) DEFAULT 0.00,
  payment_status TEXT DEFAULT 'Unpaid',
  payment_method TEXT,
  payment_reference TEXT,
  payment_remarks TEXT,
  tpa_approval_status TEXT,
  issued_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.invoice_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id UUID REFERENCES public.invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  quantity INTEGER DEFAULT 1,
  unit_price DECIMAL(10, 2) NOT NULL,
  total_price DECIMAL(10, 2) NOT NULL,
  tax_percentage DECIMAL(5, 2) DEFAULT 0.00,
  category TEXT,
  source_type TEXT, -- e.g., 'LAB_TEST', 'PHARMACY_ITEM', 'OT_PROCEDURE', 'BED_CHARGE'
  source_id UUID -- Link to the specific record in lab_tests, pharmacy_items, etc.
);

-- 11.1 Insurance Claims
CREATE TABLE IF NOT EXISTS public.insurance_claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  policy_no TEXT NOT NULL,
  insurance_company TEXT NOT NULL,
  tpa_name TEXT,
  insurance_limit DECIMAL(10, 2) DEFAULT 0.00,
  approved_amount DECIMAL(10, 2) DEFAULT 0.00,
  claim_date DATE,
  status TEXT DEFAULT 'Pending',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11.2 Discharge Summaries
CREATE TABLE IF NOT EXISTS public.discharge_summaries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admission_id UUID REFERENCES public.admissions(id) ON DELETE SET NULL,
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  discharge_type TEXT,
  follow_up_date DATE,
  medications TEXT,
  clinical_summary TEXT,
  discharge_date TIMESTAMPTZ DEFAULT NOW(),
  discharge_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. Expenses
CREATE TABLE IF NOT EXISTS public.expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  description TEXT,
  amount DECIMAL(10, 2) NOT NULL,
  expense_date DATE DEFAULT CURRENT_DATE,
  paid_to TEXT,
  status TEXT DEFAULT 'Paid',
  recorded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  attachment_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. Audit Logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  details JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13.1 OT Rooms (Operation Theatre rooms)
CREATE TABLE IF NOT EXISTS public.ot_rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  status TEXT DEFAULT 'Available',
  type TEXT DEFAULT 'Major',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. OT Management (Operation Theater)
CREATE TABLE IF NOT EXISTS public.ot_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  room_id UUID REFERENCES public.ot_rooms(id) ON DELETE SET NULL,
  ot_rooms_id UUID REFERENCES public.ot_rooms(id) ON DELETE SET NULL,
  surgeon_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  anesthetist_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  procedure_name TEXT,
  operation_name TEXT,
  surgery_date DATE,
  scheduled_date DATE,
  surgery_time TIME,
  scheduled_time TIME,
  ot_number TEXT,
  status TEXT DEFAULT 'Scheduled', -- Scheduled, In-Progress, Completed, Cancelled
  notes TEXT,
  documents JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. Nursing Observations (Specifically for Nursing Station)
CREATE TABLE IF NOT EXISTS public.nursing_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  nurse_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  alert_level TEXT DEFAULT 'normal' CHECK (alert_level IN ('normal', 'moderate', 'high')),
  is_medication_intake BOOLEAN DEFAULT FALSE,
  is_patient_request BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15.1 Nurse Shifts
CREATE TABLE IF NOT EXISTS public.nurse_shifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nurse_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  shift_type TEXT NOT NULL, -- Morning, Evening, Night
  ward TEXT NOT NULL,
  status TEXT DEFAULT 'Active',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. Lab Test Groups (Master Setup)
CREATE TABLE IF NOT EXISTS public.lab_test_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  category TEXT CHECK (category IN ('Pathology', 'Radiology')),
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. Enhanced Lab Tests (Master Setup)
-- Note: Reference columns added to existing lab_tests handle the UI fields for Master Setup
ALTER TABLE public.lab_tests ADD COLUMN IF NOT EXISTS group_id UUID REFERENCES public.lab_test_groups(id);
ALTER TABLE public.lab_tests ADD COLUMN IF NOT EXISTS unit TEXT; -- e.g., g/dL
ALTER TABLE public.lab_tests ADD COLUMN IF NOT EXISTS reference_range TEXT; -- e.g., 13.5 - 17.5
ALTER TABLE public.lab_tests ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 18. Lab Packages (Master Setup)
CREATE TABLE IF NOT EXISTS public.lab_packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  total_price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.lab_package_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id UUID REFERENCES public.lab_packages(id) ON DELETE CASCADE,
  test_id UUID REFERENCES public.lab_tests(id) ON DELETE CASCADE
);

-- 19. Maternity Records (Birth & Delivery)
CREATE TABLE IF NOT EXISTS public.birth_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mother_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  admission_id UUID REFERENCES public.admissions(id), -- Link to specific ward stay
  delivery_date DATE NOT NULL,
  delivery_time TIME NOT NULL,
  baby_gender TEXT, -- 'male', 'female'
  baby_weight DECIMAL(5, 2), -- kg
  delivery_type TEXT, -- 'normal', 'c-section', etc.
  doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure admission_id exists for existing tables
ALTER TABLE public.birth_records ADD COLUMN IF NOT EXISTS admission_id UUID REFERENCES public.admissions(id);

-- 20. External Reports (Uploaded from other centers)
CREATE TABLE IF NOT EXISTS public.external_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  report_name TEXT NOT NULL,
  report_type TEXT, -- PDF, Image, etc.
  file_url TEXT NOT NULL,
  source_center TEXT, -- Name of the external laboratory/center
  uploaded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 21. Radiology Records
CREATE TABLE IF NOT EXISTS public.radiology_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  test_name TEXT NOT NULL,
  requested_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'Ordered',
  result_notes TEXT,
  report_url TEXT,
  requested_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 22. Maternity Deliveries
CREATE TABLE IF NOT EXISTS public.maternity_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  delivery_date DATE NOT NULL,
  delivery_time TIME NOT NULL,
  delivery_type TEXT, -- Normal, C-Section, etc.
  surgeon_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 23. Maternity Newborns
CREATE TABLE IF NOT EXISTS public.maternity_newborns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mother_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  birth_weight DECIMAL(5, 2), -- kg
  gender TEXT, -- Male, Female
  birth_date_time TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 24. Nursing Handovers
CREATE TABLE IF NOT EXISTS public.nursing_handovers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  ward TEXT,
  outgoing_nurse_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  incoming_nurse_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  patient_status TEXT,
  remarkable_events TEXT,
  instructions TEXT,
  handover_date DATE,
  shift TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hospital_info ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pharmacy_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.beds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patient_vitals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lab_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pharmacy_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoice_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ot_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ot_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nursing_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nurse_shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lab_test_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lab_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lab_package_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pharmacy_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.birth_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.external_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.radiology_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maternity_deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maternity_newborns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nursing_handovers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.discharge_summaries ENABLE ROW LEVEL SECURITY;

-- Basic RLS Policies (Allow authenticated read/write access for internal staff operations)

-- Profiles Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.profiles;
CREATE POLICY "Enable read access for authenticated users" ON public.profiles FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.profiles;
CREATE POLICY "Enable insert for authenticated users" ON public.profiles FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.profiles;
CREATE POLICY "Enable update for authenticated users" ON public.profiles FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.profiles;
CREATE POLICY "Enable delete for authenticated users" ON public.profiles FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Hospital Info Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.hospital_info;
CREATE POLICY "Enable read access for authenticated users" ON public.hospital_info FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.hospital_info;
CREATE POLICY "Enable insert for authenticated users" ON public.hospital_info FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.hospital_info;
CREATE POLICY "Enable update for authenticated users" ON public.hospital_info FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.hospital_info;
CREATE POLICY "Enable delete for authenticated users" ON public.hospital_info FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Departments Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.departments;
CREATE POLICY "Enable read access for authenticated users" ON public.departments FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.departments;
CREATE POLICY "Enable insert for authenticated users" ON public.departments FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.departments;
CREATE POLICY "Enable update for authenticated users" ON public.departments FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.departments;
CREATE POLICY "Enable delete for authenticated users" ON public.departments FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Patients Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.patients;
CREATE POLICY "Enable read access for authenticated users" ON public.patients FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.patients;
CREATE POLICY "Enable insert for authenticated users" ON public.patients FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.patients;
CREATE POLICY "Enable update for authenticated users" ON public.patients FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.patients;
CREATE POLICY "Enable delete for authenticated users" ON public.patients FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Beds Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.beds;
CREATE POLICY "Enable read access for authenticated users" ON public.beds FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.beds;
CREATE POLICY "Enable insert for authenticated users" ON public.beds FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.beds;
CREATE POLICY "Enable update for authenticated users" ON public.beds FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.beds;
CREATE POLICY "Enable delete for authenticated users" ON public.beds FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Appointments Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.appointments;
CREATE POLICY "Enable read access for authenticated users" ON public.appointments FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.appointments;
CREATE POLICY "Enable insert for authenticated users" ON public.appointments FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.appointments;
CREATE POLICY "Enable update for authenticated users" ON public.appointments FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.appointments;
CREATE POLICY "Enable delete for authenticated users" ON public.appointments FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Admissions Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.admissions;
CREATE POLICY "Enable read access for authenticated users" ON public.admissions FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.admissions;
CREATE POLICY "Enable insert for authenticated users" ON public.admissions FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.admissions;
CREATE POLICY "Enable update for authenticated users" ON public.admissions FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.admissions;
CREATE POLICY "Enable delete for authenticated users" ON public.admissions FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Patient Vitals Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.patient_vitals;
CREATE POLICY "Enable read access for authenticated users" ON public.patient_vitals FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.patient_vitals;
CREATE POLICY "Enable insert for authenticated users" ON public.patient_vitals FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.patient_vitals;
CREATE POLICY "Enable update for authenticated users" ON public.patient_vitals FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.patient_vitals;
CREATE POLICY "Enable delete for authenticated users" ON public.patient_vitals FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Clinical Notes Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.clinical_notes;
CREATE POLICY "Enable read access for authenticated users" ON public.clinical_notes FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.clinical_notes;
CREATE POLICY "Enable insert for authenticated users" ON public.clinical_notes FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.clinical_notes;
CREATE POLICY "Enable update for authenticated users" ON public.clinical_notes FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.clinical_notes;
CREATE POLICY "Enable delete for authenticated users" ON public.clinical_notes FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Prescriptions Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.prescriptions;
CREATE POLICY "Enable read access for authenticated users" ON public.prescriptions FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.prescriptions;
CREATE POLICY "Enable insert for authenticated users" ON public.prescriptions FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.prescriptions;
CREATE POLICY "Enable update for authenticated users" ON public.prescriptions FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.prescriptions;
CREATE POLICY "Enable delete for authenticated users" ON public.prescriptions FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Lab Tests Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.lab_tests;
CREATE POLICY "Enable read access for authenticated users" ON public.lab_tests FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.lab_tests;
CREATE POLICY "Enable insert for authenticated users" ON public.lab_tests FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.lab_tests;
CREATE POLICY "Enable update for authenticated users" ON public.lab_tests FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.lab_tests;
CREATE POLICY "Enable delete for authenticated users" ON public.lab_tests FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Test Requests Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.test_requests;
CREATE POLICY "Enable read access for authenticated users" ON public.test_requests FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.test_requests;
CREATE POLICY "Enable insert for authenticated users" ON public.test_requests FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.test_requests;
CREATE POLICY "Enable update for authenticated users" ON public.test_requests FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.test_requests;
CREATE POLICY "Enable delete for authenticated users" ON public.test_requests FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Pharmacy Items Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.pharmacy_items;
CREATE POLICY "Enable read access for authenticated users" ON public.pharmacy_items FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.pharmacy_items;
CREATE POLICY "Enable insert for authenticated users" ON public.pharmacy_items FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.pharmacy_items;
CREATE POLICY "Enable update for authenticated users" ON public.pharmacy_items FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.pharmacy_items;
CREATE POLICY "Enable delete for authenticated users" ON public.pharmacy_items FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Pharmacy Purchases Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.pharmacy_purchases;
CREATE POLICY "Enable read access for authenticated users" ON public.pharmacy_purchases FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.pharmacy_purchases;
CREATE POLICY "Enable insert for authenticated users" ON public.pharmacy_purchases FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.pharmacy_purchases;
CREATE POLICY "Enable update for authenticated users" ON public.pharmacy_purchases FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.pharmacy_purchases;
CREATE POLICY "Enable delete for authenticated users" ON public.pharmacy_purchases FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Inventory Transactions Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.inventory_transactions;
CREATE POLICY "Enable read access for authenticated users" ON public.inventory_transactions FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.inventory_transactions;
CREATE POLICY "Enable insert for authenticated users" ON public.inventory_transactions FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.inventory_transactions;
CREATE POLICY "Enable update for authenticated users" ON public.inventory_transactions FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.inventory_transactions;
CREATE POLICY "Enable delete for authenticated users" ON public.inventory_transactions FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Invoices Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.invoices;
CREATE POLICY "Enable read access for authenticated users" ON public.invoices FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.invoices;
CREATE POLICY "Enable insert for authenticated users" ON public.invoices FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.invoices;
CREATE POLICY "Enable update for authenticated users" ON public.invoices FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.invoices;
CREATE POLICY "Enable delete for authenticated users" ON public.invoices FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Invoice Items Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.invoice_items;
CREATE POLICY "Enable read access for authenticated users" ON public.invoice_items FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.invoice_items;
CREATE POLICY "Enable insert for authenticated users" ON public.invoice_items FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.invoice_items;
CREATE POLICY "Enable update for authenticated users" ON public.invoice_items FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.invoice_items;
CREATE POLICY "Enable delete for authenticated users" ON public.invoice_items FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Insurance Claims Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.insurance_claims;
CREATE POLICY "Enable read access for authenticated users" ON public.insurance_claims FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.insurance_claims;
CREATE POLICY "Enable insert for authenticated users" ON public.insurance_claims FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.insurance_claims;
CREATE POLICY "Enable update for authenticated users" ON public.insurance_claims FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.insurance_claims;
CREATE POLICY "Enable delete for authenticated users" ON public.insurance_claims FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Expenses Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.expenses;
CREATE POLICY "Enable read access for authenticated users" ON public.expenses FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.expenses;
CREATE POLICY "Enable insert for authenticated users" ON public.expenses FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.expenses;
CREATE POLICY "Enable update for authenticated users" ON public.expenses FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.expenses;
CREATE POLICY "Enable delete for authenticated users" ON public.expenses FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Audit Logs Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.audit_logs;
CREATE POLICY "Enable read access for authenticated users" ON public.audit_logs FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.audit_logs;
CREATE POLICY "Enable insert for authenticated users" ON public.audit_logs FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.audit_logs;
CREATE POLICY "Enable update for authenticated users" ON public.audit_logs FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.audit_logs;
CREATE POLICY "Enable delete for authenticated users" ON public.audit_logs FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- OT Rooms Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.ot_rooms;
CREATE POLICY "Enable read access for authenticated users" ON public.ot_rooms FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.ot_rooms;
CREATE POLICY "Enable insert for authenticated users" ON public.ot_rooms FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.ot_rooms;
CREATE POLICY "Enable update for authenticated users" ON public.ot_rooms FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.ot_rooms;
CREATE POLICY "Enable delete for authenticated users" ON public.ot_rooms FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- OT Schedules Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.ot_schedules;
CREATE POLICY "Enable read access for authenticated users" ON public.ot_schedules FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.ot_schedules;
CREATE POLICY "Enable insert for authenticated users" ON public.ot_schedules FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.ot_schedules;
CREATE POLICY "Enable update for authenticated users" ON public.ot_schedules FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.ot_schedules;
CREATE POLICY "Enable delete for authenticated users" ON public.ot_schedules FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Nursing Notes Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.nursing_notes;
CREATE POLICY "Enable read access for authenticated users" ON public.nursing_notes FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.nursing_notes;
CREATE POLICY "Enable insert for authenticated users" ON public.nursing_notes FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.nursing_notes;
CREATE POLICY "Enable update for authenticated users" ON public.nursing_notes FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.nursing_notes;
CREATE POLICY "Enable delete for authenticated users" ON public.nursing_notes FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Nurse Shifts Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.nurse_shifts;
CREATE POLICY "Enable read access for authenticated users" ON public.nurse_shifts FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.nurse_shifts;
CREATE POLICY "Enable insert for authenticated users" ON public.nurse_shifts FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.nurse_shifts;
CREATE POLICY "Enable update for authenticated users" ON public.nurse_shifts FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.nurse_shifts;
CREATE POLICY "Enable delete for authenticated users" ON public.nurse_shifts FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Lab Test Groups Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.lab_test_groups;
CREATE POLICY "Enable read access for authenticated users" ON public.lab_test_groups FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.lab_test_groups;
CREATE POLICY "Enable insert for authenticated users" ON public.lab_test_groups FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.lab_test_groups;
CREATE POLICY "Enable update for authenticated users" ON public.lab_test_groups FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.lab_test_groups;
CREATE POLICY "Enable delete for authenticated users" ON public.lab_test_groups FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Lab Packages Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.lab_packages;
CREATE POLICY "Enable read access for authenticated users" ON public.lab_packages FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.lab_packages;
CREATE POLICY "Enable insert for authenticated users" ON public.lab_packages FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.lab_packages;
CREATE POLICY "Enable update for authenticated users" ON public.lab_packages FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.lab_packages;
CREATE POLICY "Enable delete for authenticated users" ON public.lab_packages FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Lab Package Items Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.lab_package_items;
CREATE POLICY "Enable read access for authenticated users" ON public.lab_package_items FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.lab_package_items;
CREATE POLICY "Enable insert for authenticated users" ON public.lab_package_items FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.lab_package_items;
CREATE POLICY "Enable update for authenticated users" ON public.lab_package_items FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.lab_package_items;
CREATE POLICY "Enable delete for authenticated users" ON public.lab_package_items FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Birth Records Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.birth_records;
CREATE POLICY "Enable read access for authenticated users" ON public.birth_records FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.birth_records;
CREATE POLICY "Enable insert for authenticated users" ON public.birth_records FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.birth_records;
CREATE POLICY "Enable update for authenticated users" ON public.birth_records FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.birth_records;
CREATE POLICY "Enable delete for authenticated users" ON public.birth_records FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- External Reports Policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.external_reports;
CREATE POLICY "Enable read access for authenticated users" ON public.external_reports FOR SELECT TO authenticated, anon USING (true);
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.external_reports;
CREATE POLICY "Enable insert for authenticated users" ON public.external_reports FOR INSERT TO authenticated, anon WITH CHECK (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.external_reports;
CREATE POLICY "Enable update for authenticated users" ON public.external_reports FOR UPDATE TO authenticated, anon USING (auth.role() IS NOT NULL);
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.external_reports;
CREATE POLICY "Enable delete for authenticated users" ON public.external_reports FOR DELETE TO authenticated, anon USING (auth.role() IS NOT NULL);

-- Functions and Triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ language 'plpgsql' SET search_path = '';

DROP TRIGGER IF EXISTS update_profiles_modtime ON public.profiles;
CREATE TRIGGER update_profiles_modtime BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_patients_modtime ON public.patients;
CREATE TRIGGER update_patients_modtime BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_pharmacy_items_modtime ON public.pharmacy_items;
CREATE TRIGGER update_pharmacy_items_modtime BEFORE UPDATE ON public.pharmacy_items FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_invoices_modtime ON public.invoices;
CREATE TRIGGER update_invoices_modtime BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_ot_schedules_modtime ON public.ot_schedules;
CREATE TRIGGER update_ot_schedules_modtime BEFORE UPDATE ON public.ot_schedules FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_nursing_notes_modtime ON public.nursing_notes;
CREATE TRIGGER update_nursing_notes_modtime BEFORE UPDATE ON public.nursing_notes FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_lab_tests_modtime ON public.lab_tests;
CREATE TRIGGER update_lab_tests_modtime BEFORE UPDATE ON public.lab_tests FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_lab_packages_modtime ON public.lab_packages;
CREATE TRIGGER update_lab_packages_modtime BEFORE UPDATE ON public.lab_packages FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_birth_records_modtime ON public.birth_records;
CREATE TRIGGER update_birth_records_modtime BEFORE UPDATE ON public.birth_records FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_external_reports_modtime ON public.external_reports;
CREATE TRIGGER update_external_reports_modtime BEFORE UPDATE ON public.external_reports FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_patient_vitals_modtime ON public.patient_vitals;
CREATE TRIGGER update_patient_vitals_modtime BEFORE UPDATE ON public.patient_vitals FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_radiology_records_modtime ON public.radiology_records;
CREATE TRIGGER update_radiology_records_modtime BEFORE UPDATE ON public.radiology_records FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_maternity_deliveries_modtime ON public.maternity_deliveries;
CREATE TRIGGER update_maternity_deliveries_modtime BEFORE UPDATE ON public.maternity_deliveries FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_maternity_newborns_modtime ON public.maternity_newborns;
CREATE TRIGGER update_maternity_newborns_modtime BEFORE UPDATE ON public.maternity_newborns FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_nursing_handovers_modtime ON public.nursing_handovers;
CREATE TRIGGER update_nursing_handovers_modtime BEFORE UPDATE ON public.nursing_handovers FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

DROP TRIGGER IF EXISTS update_discharge_summaries_modtime ON public.discharge_summaries;
CREATE TRIGGER update_discharge_summaries_modtime BEFORE UPDATE ON public.discharge_summaries FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- 15.2 Automated Maternity Sync: Inserts a newborn automatically when a delivery is recorded
CREATE OR REPLACE FUNCTION public.sync_delivery_to_newborn()
RETURNS TRIGGER AS $$
DECLARE
  weight_val DECIMAL(5,2) := 3.2;
  gender_val TEXT := 'Male';
  weight_match TEXT;
  gender_match TEXT;
BEGIN
  -- Parse weight and gender from notes if present
  IF NEW.notes IS NOT NULL THEN
    weight_match := substring(NEW.notes from '(?i)weight:\s*([0-9.]+)');
    gender_match := substring(NEW.notes from '(?i)gender:\s*(\w+)');
    IF weight_match IS NOT NULL THEN
      weight_val := weight_match::DECIMAL(5,2);
    END IF;
    IF gender_match IS NOT NULL THEN
      gender_val := initcap(gender_match);
    END IF;
  END IF;

  INSERT INTO public.maternity_newborns (mother_id, birth_weight, gender, birth_date_time)
  VALUES (
    NEW.patient_id, 
    weight_val, 
    gender_val, 
    (NEW.delivery_date::text || 'T' || NEW.delivery_time::text)::timestamptz
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Revoke execute from public roles as it is not meant to be callable by users
REVOKE EXECUTE ON FUNCTION public.sync_delivery_to_newborn() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS sync_delivery_to_newborn_trigger ON public.maternity_deliveries;
CREATE TRIGGER sync_delivery_to_newborn_trigger
AFTER INSERT ON public.maternity_deliveries
FOR EACH ROW EXECUTE FUNCTION public.sync_delivery_to_newborn();

-- SEED DATA --

-- Initial Lab Groups
INSERT INTO public.lab_test_groups (name, category) VALUES
('Biochemistry', 'Pathology'),
('Hematology', 'Pathology'),
('Microbiology', 'Pathology'),
('Serology', 'Pathology'),
('Histopathology', 'Pathology'),
('X-Ray', 'Radiology'),
('Ultrasound', 'Radiology'),
('CT Scan', 'Radiology'),
('MRI', 'Radiology')
ON CONFLICT (name) DO NOTHING;

-- Initial Departments
INSERT INTO public.departments (name, description) VALUES
('General Medicine', 'Standard outpatient and inpatient care'),
('Cardiology', 'Heart and cardiovascular system care'),
('Orthopedics', 'Musculoskeletal system care'),
('Pediatrics', 'Children and adolescent medical care'),
('Obstetrics & Gynecology', 'Female reproductive health and childbirth'),
('Surgery', 'General and specialized surgical procedures'),
('Emergency', 'Critical care and immediate response'),
('Radiology', 'Diagnostic imaging services'),
('Pathology', 'Laboratory diagnostic services')
ON CONFLICT (name) DO NOTHING;

-- Initial Lab Tests
INSERT INTO public.lab_tests (name, category, price) VALUES
('CBC (Complete Blood Count)', 'Pathology', 150.00),
('LFT (Liver Function Test)', 'Pathology', 450.00),
('KFT (Kidney Function Test)', 'Pathology', 500.00),
('Blood Sugar (F/PP)', 'Pathology', 80.00),
('Lipid Profile', 'Pathology', 600.00),
('Urine Routine', 'Pathology', 100.00),
('Chest X-Ray', 'Radiology', 250.00),
('Ultrasound (Whole Abdomen)', 'Radiology', 800.00),
('CT Scan (Brain)', 'Radiology', 3500.00);

-- Initial OT Rooms
INSERT INTO public.ot_rooms (name, status, type) VALUES
('Operation Theatre 1 (Major)', 'Available', 'Major'),
('Operation Theatre 2 (Minor)', 'Available', 'Minor'),
('Operation Theatre 3 (Cardiac)', 'Available', 'Cardiac'),
('Operation Theatre 4 (Orthopedic)', 'Available', 'Orthopedic'),
('Operation Theatre 5 (Emergency)', 'Available', 'Emergency')
ON CONFLICT (name) DO NOTHING;

-- VIEWS --

-- Daily Revenue View
CREATE OR REPLACE VIEW public.daily_revenue 
WITH (security_invoker = true)
AS
SELECT 
  created_at::DATE as date,
  SUM(paid_amount) as total_revenue
FROM public.invoices
WHERE payment_status IN ('Fully Paid', 'Partially Paid')
GROUP BY created_at::DATE
ORDER BY date DESC;

-- Bed Occupancy View
CREATE OR REPLACE VIEW public.bed_occupancy_summary 
WITH (security_invoker = true)
AS
SELECT 
  ward,
  COUNT(*) as total_beds,
  SUM(CASE WHEN status = 'Occupied' THEN 1 ELSE 0 END) as occupied_beds,
  SUM(CASE WHEN status = 'Available' THEN 1 ELSE 0 END) as available_beds
FROM public.beds
GROUP BY ward;

-- Maternity Ward Specific View
CREATE OR REPLACE VIEW public.maternity_ward_summary
WITH (security_invoker = true)
AS
SELECT 
  p.id as patient_id,
  p.name as patient_name,
  p.mrn,
  b.bed_number,
  a.admission_date,
  br.delivery_date,
  br.delivery_time,
  br.baby_gender,
  br.delivery_type,
  a.status as admission_status
FROM public.patients p
JOIN public.admissions a ON p.id = a.patient_id
JOIN public.beds b ON a.bed_id = b.id
LEFT JOIN public.birth_records br ON p.id = br.mother_id AND a.id = br.admission_id
WHERE b.ward ILIKE '%Maternity%' AND a.status = 'Admitted';

-- Patient 360 Activity Timeline View
CREATE OR REPLACE VIEW public.patient_timeline
WITH (security_invoker = true)
AS
SELECT patient_id, 'VITAL' as activity_type, 'Vitals recorded' as description, recorded_at as activity_date, (SELECT name FROM profiles WHERE id = recorded_by) as performed_by FROM public.patient_vitals
UNION ALL
SELECT patient_id, 'NOTE', 'Clinical note added: ' || note_type, created_at, (SELECT name FROM profiles WHERE id = author_id) FROM public.clinical_notes
UNION ALL
SELECT patient_id, 'TEST', 'Lab test requested', requested_at, (SELECT name FROM profiles WHERE id = requested_by) FROM public.test_requests
UNION ALL
SELECT patient_id, 'INVOICE', 'Bill generated: ' || invoice_number, created_at, (SELECT name FROM profiles WHERE id = issued_by) FROM public.invoices
UNION ALL
SELECT patient_id, 'ADMISSION', 'Patient admitted', admission_date, (SELECT name FROM profiles WHERE id = doctor_id) FROM public.admissions
UNION ALL
SELECT patient_id, 'SURGERY', 'OT Procedure: ' || procedure_name, created_at, (SELECT name FROM profiles WHERE id = surgeon_id) FROM public.ot_schedules;


-- 1. Update pharmacy_items table
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS generic_name TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS category TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS stock_quantity INTEGER DEFAULT 0;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS reorder_level INTEGER DEFAULT 10;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS min_stock_level INTEGER DEFAULT 10;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS unit TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS expiry_date DATE;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS purchase_price DECIMAL(10, 2);
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS sale_price DECIMAL(10, 2);
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS mrp DECIMAL(10, 2);
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS tax_percentage DECIMAL(5, 2) DEFAULT 0.00;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS hsn_code TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS batch_number TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS rack_number TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS manufacturer TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS composition TEXT;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS is_loose_sale_enabled BOOLEAN DEFAULT FALSE;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS units_per_strip INTEGER DEFAULT 10;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS loose_selling_price DECIMAL(10, 2) DEFAULT 0.00;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS loose_stock INTEGER DEFAULT 0;

-- 2. Update invoice_items table to track tax per item
ALTER TABLE public.invoice_items ADD COLUMN IF NOT EXISTS tax_percentage DECIMAL(5, 2) DEFAULT 0.00;

-- 3. (Optional) Rename sale_price to selling_price for clarity if needed, 
-- but we'll stick to the existing column for compatibility
-- ALTER TABLE public.pharmacy_items RENAME COLUMN sale_price TO selling_price;

-- Example of how to populate initial data for a new item with these fields
/*
INSERT INTO public.pharmacy_items (
  name, 
  category, 
  stock_quantity, 
  unit, 
  purchase_price, 
  sale_price, 
  mrp, 
  tax_percentage, 
  hsn_code, 
  batch_number, 
  rack_number
) VALUES (
  'Paracetamol 500mg', 
  'Medicine', 
  100, 
  'Tablets', 
  8.00, 
  12.00, 
  15.50, 
  12.00, 
  '3004', 
  'BTCH123', 
  'A-101'
);
*/

-- 25. Bio-Medical Waste Collection & Transfers
CREATE TABLE IF NOT EXISTS public.bio_waste_collections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  custom_id TEXT UNIQUE NOT NULL,
  category TEXT NOT NULL,
  weight NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  ward TEXT NOT NULL,
  logged_by TEXT NOT NULL,
  collection_date DATE NOT NULL DEFAULT CURRENT_DATE,
  collection_time TIME NOT NULL DEFAULT CURRENT_TIME,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.bio_waste_transfers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  custom_id TEXT UNIQUE NOT NULL,
  agency_name TEXT NOT NULL,
  vehicle_no TEXT NOT NULL,
  driver_name TEXT NOT NULL,
  total_weight NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  transfer_date DATE NOT NULL DEFAULT CURRENT_DATE,
  certificate_ref TEXT NOT NULL,
  remarks TEXT,
  status TEXT DEFAULT 'Handed Over',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- END OF SCHEMA --
-- AUTOMATIC SYSTEM CONFIGURATION: Enforces RLS globally and configures secure, fully open policies to guarantee global front-end sync with Zero-Error CRUD operations.
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN (
        SELECT tablename
        FROM pg_tables
        WHERE schemaname = 'public'
    )
    LOOP
        -- 1. Ensure RLS is fully enabled on all tables in compliance with security guidelines
        EXECUTE 'ALTER TABLE public.' || quote_ident(r.tablename) || ' ENABLE ROW LEVEL SECURITY;';

        -- 2. Clean up any existing policies first to prevent "policy already exists" conflicts on subsequent script executions
        EXECUTE 'DROP POLICY IF EXISTS "Allow public select" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Allow public insert" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Allow public update" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Allow public delete" ON public.' || quote_ident(r.tablename);
        
        EXECUTE 'DROP POLICY IF EXISTS "Allow authenticated users full access" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.' || quote_ident(r.tablename);

        -- 3. App-compatible permissive secure policies ensuring standard front-end clients from any coordinate sync correctly
        EXECUTE 'CREATE POLICY "Allow public select" ON public.' || quote_ident(r.tablename) || ' FOR SELECT TO authenticated, anon USING (true);';
        EXECUTE 'CREATE POLICY "Allow public insert" ON public.' || quote_ident(r.tablename) || ' FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '''') IS NOT NULL);';
        EXECUTE 'CREATE POLICY "Allow public update" ON public.' || quote_ident(r.tablename) || ' FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '''') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '''') IS NOT NULL);';
        EXECUTE 'CREATE POLICY "Allow public delete" ON public.' || quote_ident(r.tablename) || ' FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '''') IS NOT NULL);';
    END LOOP;
END $$;

ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

-- ==========================================
-- HELPER MIGRATION SCRIPT FOR EXISTING DATABASES
-- Run this block in your Supabase SQL Editor if you are patching an existing database
-- ==========================================

-- 1. Ensure ot_schedules has all necessary columns regardless of older schema iterations
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS scheduled_date DATE;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS scheduled_time TIME;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS surgery_date DATE;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS surgery_time TIME;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS operation_name TEXT;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS procedure_name TEXT;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS room_id UUID;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS ot_rooms_id UUID;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS surgeon_id UUID;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS anesthetist_id UUID;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS ot_number TEXT;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Scheduled';
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE public.ot_schedules ADD COLUMN IF NOT EXISTS documents JSONB DEFAULT '[]'::jsonb;

-- 2. Modify existing foreign keys to ON DELETE SET NULL to allow seamless deletion of staff
ALTER TABLE public.departments DROP CONSTRAINT IF EXISTS departments_head_id_fkey;
ALTER TABLE public.departments ADD CONSTRAINT departments_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_doctor_id_fkey;
ALTER TABLE public.appointments ADD CONSTRAINT appointments_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.admissions DROP CONSTRAINT IF EXISTS admissions_doctor_id_fkey;
ALTER TABLE public.admissions ADD CONSTRAINT admissions_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.patient_vitals DROP CONSTRAINT IF EXISTS patient_vitals_recorded_by_fkey;
ALTER TABLE public.patient_vitals ADD CONSTRAINT patient_vitals_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.clinical_notes DROP CONSTRAINT IF EXISTS clinical_notes_author_id_fkey;
ALTER TABLE public.clinical_notes ADD CONSTRAINT clinical_notes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.prescriptions DROP CONSTRAINT IF EXISTS prescriptions_doctor_id_fkey;
ALTER TABLE public.prescriptions ADD CONSTRAINT prescriptions_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.test_requests DROP CONSTRAINT IF EXISTS test_requests_requested_by_fkey;
ALTER TABLE public.test_requests ADD CONSTRAINT test_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.pharmacy_purchases DROP CONSTRAINT IF EXISTS pharmacy_purchases_recorded_by_fkey;
ALTER TABLE public.pharmacy_purchases ADD CONSTRAINT pharmacy_purchases_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_performed_by_fkey;
ALTER TABLE public.inventory_transactions ADD CONSTRAINT inventory_transactions_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.invoices DROP CONSTRAINT IF EXISTS invoices_issued_by_fkey;
ALTER TABLE public.invoices ADD CONSTRAINT invoices_issued_by_fkey FOREIGN KEY (issued_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.expenses DROP CONSTRAINT IF EXISTS expenses_recorded_by_fkey;
ALTER TABLE public.expenses ADD CONSTRAINT expenses_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_user_id_fkey;
ALTER TABLE public.audit_logs ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.ot_schedules DROP CONSTRAINT IF EXISTS ot_schedules_surgeon_id_fkey;
ALTER TABLE public.ot_schedules ADD CONSTRAINT ot_schedules_surgeon_id_fkey FOREIGN KEY (surgeon_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.ot_schedules DROP CONSTRAINT IF EXISTS ot_schedules_anesthetist_id_fkey;
ALTER TABLE public.ot_schedules ADD CONSTRAINT ot_schedules_anesthetist_id_fkey FOREIGN KEY (anesthetist_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.nursing_notes DROP CONSTRAINT IF EXISTS nursing_notes_nurse_id_fkey;
ALTER TABLE public.nursing_notes ADD CONSTRAINT nursing_notes_nurse_id_fkey FOREIGN KEY (nurse_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.birth_records DROP CONSTRAINT IF EXISTS birth_records_doctor_id_fkey;
ALTER TABLE public.birth_records ADD CONSTRAINT birth_records_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.external_reports DROP CONSTRAINT IF EXISTS external_reports_uploaded_by_fkey;
ALTER TABLE public.external_reports ADD CONSTRAINT external_reports_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.radiology_records DROP CONSTRAINT IF EXISTS radiology_records_requested_by_fkey;
ALTER TABLE public.radiology_records ADD CONSTRAINT radiology_records_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.maternity_deliveries DROP CONSTRAINT IF EXISTS maternity_deliveries_surgeon_id_fkey;
ALTER TABLE public.maternity_deliveries ADD CONSTRAINT maternity_deliveries_surgeon_id_fkey FOREIGN KEY (surgeon_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.nursing_handovers DROP CONSTRAINT IF EXISTS nursing_handovers_outgoing_nurse_id_fkey;
ALTER TABLE public.nursing_handovers ADD CONSTRAINT nursing_handovers_outgoing_nurse_id_fkey FOREIGN KEY (outgoing_nurse_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.nursing_handovers DROP CONSTRAINT IF EXISTS nursing_handovers_incoming_nurse_id_fkey;
ALTER TABLE public.nursing_handovers ADD CONSTRAINT nursing_handovers_incoming_nurse_id_fkey FOREIGN KEY (incoming_nurse_id) REFERENCES public.profiles(id) ON DELETE SET NULL;

-- Ensure test_requests table contains custom columns for lab test orders
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS test_name TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS reference_range TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS unit TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS urgency TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS result_value TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS clinical_notes TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS findings TEXT;

-- 19. Pathology LIMS Relational Schema
-- Category Master Table
CREATE TABLE IF NOT EXISTS public.test_categories (
    cat_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_name TEXT UNIQUE NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Sub-Category Master Table
CREATE TABLE IF NOT EXISTS public.test_subcategories (
    subcat_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id UUID NOT NULL REFERENCES public.test_categories(cat_id) ON DELETE CASCADE,
    subcategory_name TEXT NOT NULL,
    description TEXT,
    CONSTRAINT uq_cat_sub UNIQUE (category_id, subcategory_name)
);

-- Unit Master Table
CREATE TABLE IF NOT EXISTS public.test_units (
    unit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_name TEXT NOT NULL,
    unit_symbol TEXT UNIQUE NOT NULL
);

-- Investigation/Test Master Table (Tests like CBC, LFT, Lipid)
CREATE TABLE IF NOT EXISTS public.investigation_tests (
    test_code VARCHAR(30) PRIMARY KEY,
    test_name TEXT NOT NULL,
    short_name VARCHAR(30) NOT NULL,
    department TEXT NOT NULL,
    category_id UUID REFERENCES public.test_categories(cat_id) ON DELETE SET NULL,
    subcategory_id UUID REFERENCES public.test_subcategories(subcat_id) ON DELETE SET NULL,
    sample_type TEXT NOT NULL,
    processing_method TEXT DEFAULT 'Automated',
    machine_name TEXT,
    report_type TEXT DEFAULT 'Quantitative' CHECK (report_type IN ('Quantitative', 'Qualitative', 'Narrative')),
    tat_hours TEXT DEFAULT '6 Hours',
    normal_range_applicable BOOLEAN DEFAULT TRUE,
    critical_value_applicable BOOLEAN DEFAULT TRUE,
    nabl_compliance BOOLEAN DEFAULT TRUE,
    price DECIMAL(10,2) DEFAULT '0.00'::numeric,
    status TEXT DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_investigation_tests_name ON public.investigation_tests (test_name);

-- Test Parameter Master Table
CREATE TABLE IF NOT EXISTS public.test_parameters (
    parameter_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_code VARCHAR(30) NOT NULL REFERENCES public.investigation_tests(test_code) ON DELETE CASCADE,
    parameter_name TEXT NOT NULL,
    unit_symbol TEXT,
    decimal_places INT DEFAULT 1,
    sequence_no INT DEFAULT 10,
    formula_based BOOLEAN DEFAULT FALSE,
    calculation_formula TEXT
);

CREATE INDEX IF NOT EXISTS idx_test_parameters_code ON public.test_parameters (test_code);

-- Age & Gender Based Reference Range Master Table
CREATE TABLE IF NOT EXISTS public.parameter_reference_ranges (
    range_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    parameter_id UUID NOT NULL REFERENCES public.test_parameters(parameter_id) ON DELETE CASCADE,
    gender TEXT DEFAULT 'All' CHECK (gender IN ('Male', 'Female', 'Other', 'All')),
    age_group TEXT DEFAULT 'All' CHECK (age_group IN ('Newborn', 'Infant', 'Child', 'Adolescent', 'Adult', 'Senior', 'All')),
    low_range_val DECIMAL(12,4) NOT NULL,
    high_range_val DECIMAL(12,4) NOT NULL,
    critical_low_val DECIMAL(12,4),
    critical_high_val DECIMAL(12,4)
);

CREATE INDEX IF NOT EXISTS idx_ref_ranges_parameter ON public.parameter_reference_ranges (parameter_id);

-- Critical Value Calibration Master Table
CREATE TABLE IF NOT EXISTS public.parameter_critical_ranges (
    config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    parameter_id UUID UNIQUE NOT NULL REFERENCES public.test_parameters(parameter_id) ON DELETE CASCADE,
    low_critical_limit DECIMAL(12,4) NOT NULL,
    high_critical_limit DECIMAL(12,4) NOT NULL,
    alert_message TEXT NOT NULL
);

-- Sample Collection & Transit Registry Table
CREATE TABLE IF NOT EXISTS public.sample_registrations (
    sample_id VARCHAR(36) PRIMARY KEY,
    pat_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
    collected_by_id UUID,
    collection_status TEXT DEFAULT 'Pending' CHECK (collection_status IN ('Pending', 'Collected', 'Received', 'In-Transit', 'Rejected')),
    collection_time TIMESTAMPTZ,
    transit_received_time TIMESTAMPTZ,
    rejection_reason_notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_sample_reg_status ON public.sample_registrations (collection_status);

-- LIS Results Logging Table
CREATE TABLE IF NOT EXISTS public.lis_results_releases (
    release_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sample_id VARCHAR(36) NOT NULL REFERENCES public.sample_registrations(sample_id) ON DELETE CASCADE,
    test_code VARCHAR(30) NOT NULL REFERENCES public.investigation_tests(test_code) ON DELETE CASCADE,
    pathologist_comments TEXT,
    verified_by_doctor TEXT,
    released_timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    delta_check_audit TEXT,
    CONSTRAINT uq_sample_test UNIQUE (sample_id, test_code)
);

-- Individual Parameters Result Metrics Table
CREATE TABLE IF NOT EXISTS public.parameter_result_values (
    val_id BIGSERIAL PRIMARY KEY,
    release_id UUID NOT NULL REFERENCES public.lis_results_releases(release_id) ON DELETE CASCADE,
    parameter_id UUID NOT NULL REFERENCES public.test_parameters(parameter_id) ON DELETE CASCADE,
    observed_value TEXT NOT NULL,
    observed_status TEXT DEFAULT 'Normal' CHECK (observed_status IN ('Normal', 'Low', 'High', 'Critical'))
);

-- Enable Row Level Security (RLS) on all new LIMS tables
ALTER TABLE public.test_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_subcategories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_units ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.investigation_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_parameters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parameter_reference_ranges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parameter_critical_ranges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sample_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lis_results_releases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parameter_result_values ENABLE ROW LEVEL SECURITY;

-- Create Policies for Authenticated & Public access inside Supabase SQL Editor
DROP POLICY IF EXISTS "Allow public read for test_categories" ON public.test_categories;
CREATE POLICY "Allow public read for test_categories" ON public.test_categories FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for test_categories" ON public.test_categories;
DROP POLICY IF EXISTS "Allow public insert for test_categories" ON public.test_categories;
DROP POLICY IF EXISTS "Allow public update for test_categories" ON public.test_categories;
DROP POLICY IF EXISTS "Allow public delete for test_categories" ON public.test_categories;
CREATE POLICY "Allow public insert for test_categories" ON public.test_categories FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for test_categories" ON public.test_categories FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for test_categories" ON public.test_categories FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for test_subcategories" ON public.test_subcategories;
CREATE POLICY "Allow public read for test_subcategories" ON public.test_subcategories FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for test_subcategories" ON public.test_subcategories;
DROP POLICY IF EXISTS "Allow public insert for test_subcategories" ON public.test_subcategories;
DROP POLICY IF EXISTS "Allow public update for test_subcategories" ON public.test_subcategories;
DROP POLICY IF EXISTS "Allow public delete for test_subcategories" ON public.test_subcategories;
CREATE POLICY "Allow public insert for test_subcategories" ON public.test_subcategories FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for test_subcategories" ON public.test_subcategories FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for test_subcategories" ON public.test_subcategories FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for test_units" ON public.test_units;
CREATE POLICY "Allow public read for test_units" ON public.test_units FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for test_units" ON public.test_units;
DROP POLICY IF EXISTS "Allow public insert for test_units" ON public.test_units;
DROP POLICY IF EXISTS "Allow public update for test_units" ON public.test_units;
DROP POLICY IF EXISTS "Allow public delete for test_units" ON public.test_units;
CREATE POLICY "Allow public insert for test_units" ON public.test_units FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for test_units" ON public.test_units FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for test_units" ON public.test_units FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for investigation_tests" ON public.investigation_tests;
CREATE POLICY "Allow public read for investigation_tests" ON public.investigation_tests FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for investigation_tests" ON public.investigation_tests;
DROP POLICY IF EXISTS "Allow public insert for investigation_tests" ON public.investigation_tests;
DROP POLICY IF EXISTS "Allow public update for investigation_tests" ON public.investigation_tests;
DROP POLICY IF EXISTS "Allow public delete for investigation_tests" ON public.investigation_tests;
CREATE POLICY "Allow public insert for investigation_tests" ON public.investigation_tests FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for investigation_tests" ON public.investigation_tests FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for investigation_tests" ON public.investigation_tests FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for test_parameters" ON public.test_parameters;
CREATE POLICY "Allow public read for test_parameters" ON public.test_parameters FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for test_parameters" ON public.test_parameters;
DROP POLICY IF EXISTS "Allow public insert for test_parameters" ON public.test_parameters;
DROP POLICY IF EXISTS "Allow public update for test_parameters" ON public.test_parameters;
DROP POLICY IF EXISTS "Allow public delete for test_parameters" ON public.test_parameters;
CREATE POLICY "Allow public insert for test_parameters" ON public.test_parameters FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for test_parameters" ON public.test_parameters FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for test_parameters" ON public.test_parameters FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for parameter_reference_ranges" ON public.parameter_reference_ranges;
CREATE POLICY "Allow public read for parameter_reference_ranges" ON public.parameter_reference_ranges FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for parameter_reference_ranges" ON public.parameter_reference_ranges;
DROP POLICY IF EXISTS "Allow public insert for parameter_reference_ranges" ON public.parameter_reference_ranges;
DROP POLICY IF EXISTS "Allow public update for parameter_reference_ranges" ON public.parameter_reference_ranges;
DROP POLICY IF EXISTS "Allow public delete for parameter_reference_ranges" ON public.parameter_reference_ranges;
CREATE POLICY "Allow public insert for parameter_reference_ranges" ON public.parameter_reference_ranges FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for parameter_reference_ranges" ON public.parameter_reference_ranges FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for parameter_reference_ranges" ON public.parameter_reference_ranges FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for parameter_critical_ranges" ON public.parameter_critical_ranges;
CREATE POLICY "Allow public read for parameter_critical_ranges" ON public.parameter_critical_ranges FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for parameter_critical_ranges" ON public.parameter_critical_ranges;
DROP POLICY IF EXISTS "Allow public insert for parameter_critical_ranges" ON public.parameter_critical_ranges;
DROP POLICY IF EXISTS "Allow public update for parameter_critical_ranges" ON public.parameter_critical_ranges;
DROP POLICY IF EXISTS "Allow public delete for parameter_critical_ranges" ON public.parameter_critical_ranges;
CREATE POLICY "Allow public insert for parameter_critical_ranges" ON public.parameter_critical_ranges FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for parameter_critical_ranges" ON public.parameter_critical_ranges FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for parameter_critical_ranges" ON public.parameter_critical_ranges FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for sample_registrations" ON public.sample_registrations;
CREATE POLICY "Allow public read for sample_registrations" ON public.sample_registrations FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for sample_registrations" ON public.sample_registrations;
DROP POLICY IF EXISTS "Allow public insert for sample_registrations" ON public.sample_registrations;
DROP POLICY IF EXISTS "Allow public update for sample_registrations" ON public.sample_registrations;
DROP POLICY IF EXISTS "Allow public delete for sample_registrations" ON public.sample_registrations;
CREATE POLICY "Allow public insert for sample_registrations" ON public.sample_registrations FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for sample_registrations" ON public.sample_registrations FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for sample_registrations" ON public.sample_registrations FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for lis_results_releases" ON public.lis_results_releases;
CREATE POLICY "Allow public read for lis_results_releases" ON public.lis_results_releases FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for lis_results_releases" ON public.lis_results_releases;
DROP POLICY IF EXISTS "Allow public insert for lis_results_releases" ON public.lis_results_releases;
DROP POLICY IF EXISTS "Allow public update for lis_results_releases" ON public.lis_results_releases;
DROP POLICY IF EXISTS "Allow public delete for lis_results_releases" ON public.lis_results_releases;
CREATE POLICY "Allow public insert for lis_results_releases" ON public.lis_results_releases FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for lis_results_releases" ON public.lis_results_releases FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for lis_results_releases" ON public.lis_results_releases FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

DROP POLICY IF EXISTS "Allow public read for parameter_result_values" ON public.parameter_result_values;
CREATE POLICY "Allow public read for parameter_result_values" ON public.parameter_result_values FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public write for parameter_result_values" ON public.parameter_result_values;
DROP POLICY IF EXISTS "Allow public insert for parameter_result_values" ON public.parameter_result_values;
DROP POLICY IF EXISTS "Allow public update for parameter_result_values" ON public.parameter_result_values;
DROP POLICY IF EXISTS "Allow public delete for parameter_result_values" ON public.parameter_result_values;
CREATE POLICY "Allow public insert for parameter_result_values" ON public.parameter_result_values FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public update for parameter_result_values" ON public.parameter_result_values FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
CREATE POLICY "Allow public delete for parameter_result_values" ON public.parameter_result_values FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- Add referral columns to patients table if they do not exist
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS is_referral BOOLEAN DEFAULT FALSE;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS referred_by TEXT;

-- Blood Donations Table
CREATE TABLE IF NOT EXISTS public.blood_donations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  age INTEGER NOT NULL,
  gender TEXT NOT NULL,
  blood_group TEXT NOT NULL,
  bp TEXT NOT NULL,
  hemoglobin DECIMAL(4, 2) NOT NULL,
  status TEXT NOT NULL, -- 'Fit', 'Deferred'
  last_donation DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for blood_donations
ALTER TABLE public.blood_donations ENABLE ROW LEVEL SECURITY;

-- Policies for blood_donations
DROP POLICY IF EXISTS "Allow public read for blood_donations" ON public.blood_donations;
CREATE POLICY "Allow public read for blood_donations" ON public.blood_donations FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for blood_donations" ON public.blood_donations;
CREATE POLICY "Allow public insert for blood_donations" ON public.blood_donations FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for blood_donations" ON public.blood_donations;
CREATE POLICY "Allow public update for blood_donations" ON public.blood_donations FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for blood_donations" ON public.blood_donations;
CREATE POLICY "Allow public delete for blood_donations" ON public.blood_donations FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- Blood Issues Table
CREATE TABLE IF NOT EXISTS public.blood_issues (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_name TEXT NOT NULL,
  mrn TEXT NOT NULL,
  blood_group TEXT NOT NULL,
  bag_no TEXT NOT NULL,
  ward TEXT,
  issued_by TEXT NOT NULL,
  date DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for blood_issues
ALTER TABLE public.blood_issues ENABLE ROW LEVEL SECURITY;

-- Policies for blood_issues
DROP POLICY IF EXISTS "Allow public read for blood_issues" ON public.blood_issues;
CREATE POLICY "Allow public read for blood_issues" ON public.blood_issues FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for blood_issues" ON public.blood_issues;
CREATE POLICY "Allow public insert for blood_issues" ON public.blood_issues FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for blood_issues" ON public.blood_issues;
CREATE POLICY "Allow public update for blood_issues" ON public.blood_issues FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for blood_issues" ON public.blood_issues;
CREATE POLICY "Allow public delete for blood_issues" ON public.blood_issues FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- REFRESH SCHEMA CACHE FOR POSTGREST (SUPER IMPORTANT AFTER EXECUTING ALTER STATEMENTS)
NOTIFY pgrst, 'reload schema';

-- Medical Equipment Table
CREATE TABLE IF NOT EXISTS public.medical_equipment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  department TEXT NOT NULL,
  model TEXT NOT NULL,
  serial_number TEXT NOT NULL,
  install_date DATE,
  status TEXT NOT NULL DEFAULT 'Operational',
  last_pm_date DATE,
  next_pm_date DATE,
  amc_vendor TEXT,
  amc_expiry DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for medical_equipment
ALTER TABLE public.medical_equipment ENABLE ROW LEVEL SECURITY;

-- Policies for medical_equipment
DROP POLICY IF EXISTS "Allow public read for medical_equipment" ON public.medical_equipment;
CREATE POLICY "Allow public read for medical_equipment" ON public.medical_equipment FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for medical_equipment" ON public.medical_equipment;
CREATE POLICY "Allow public insert for medical_equipment" ON public.medical_equipment FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for medical_equipment" ON public.medical_equipment;
CREATE POLICY "Allow public update for medical_equipment" ON public.medical_equipment FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for medical_equipment" ON public.medical_equipment;
CREATE POLICY "Allow public delete for medical_equipment" ON public.medical_equipment FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- Equipment Breakdowns Table
CREATE TABLE IF NOT EXISTS public.equipment_breakdowns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  equipment_id UUID REFERENCES public.medical_equipment(id) ON DELETE CASCADE,
  reported_by TEXT NOT NULL,
  reported_date DATE NOT NULL,
  description TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending',
  estimated_cost DECIMAL(12, 2) DEFAULT 0.00,
  resolved_date DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for equipment_breakdowns
ALTER TABLE public.equipment_breakdowns ENABLE ROW LEVEL SECURITY;

-- Policies for equipment_breakdowns
DROP POLICY IF EXISTS "Allow public read for equipment_breakdowns" ON public.equipment_breakdowns;
CREATE POLICY "Allow public read for equipment_breakdowns" ON public.equipment_breakdowns FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for equipment_breakdowns" ON public.equipment_breakdowns;
CREATE POLICY "Allow public insert for equipment_breakdowns" ON public.equipment_breakdowns FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for equipment_breakdowns" ON public.equipment_breakdowns;
CREATE POLICY "Allow public update for equipment_breakdowns" ON public.equipment_breakdowns FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for equipment_breakdowns" ON public.equipment_breakdowns;
CREATE POLICY "Allow public delete for equipment_breakdowns" ON public.equipment_breakdowns FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- Alter patients table to add bed column if not exists
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS bed TEXT;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS urgency TEXT DEFAULT 'Routine';

-- Alter nursing_notes table to add ward task columns if not exists
ALTER TABLE public.nursing_notes ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE public.nursing_notes ADD COLUMN IF NOT EXISTS priority TEXT;
ALTER TABLE public.nursing_notes ADD COLUMN IF NOT EXISTS due_time TEXT;
ALTER TABLE public.nursing_notes ADD COLUMN IF NOT EXISTS type TEXT;
ALTER TABLE public.nursing_notes ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Pending';

-- 12. Emergency Cases (Trauma / Triage) Table
CREATE TABLE IF NOT EXISTS public.emergency_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  age INTEGER,
  gender TEXT,
  phone TEXT,
  mrn TEXT,
  triage_level TEXT NOT NULL,
  triage_color TEXT,
  presenting_complaints TEXT NOT NULL,
  mechanism_of_injury TEXT,
  arrival_mode TEXT NOT NULL,
  arrival_time TEXT,
  arrival_date DATE,
  bed_id TEXT,
  assigned_doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  assigned_doctor_name TEXT,
  assigned_nurse_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  assigned_nurse_name TEXT,
  status TEXT NOT NULL DEFAULT 'Triaged',
  is_referral BOOLEAN DEFAULT FALSE,
  referred_by TEXT,
  vitals JSONB,
  assessments JSONB,
  interventions JSONB,
  disposition_reason TEXT,
  disposition_destination TEXT,
  disposition_time TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.emergency_cases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read for emergency_cases" ON public.emergency_cases;
CREATE POLICY "Allow public read for emergency_cases" ON public.emergency_cases FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for emergency_cases" ON public.emergency_cases;
CREATE POLICY "Allow public insert for emergency_cases" ON public.emergency_cases FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for emergency_cases" ON public.emergency_cases;
CREATE POLICY "Allow public update for emergency_cases" ON public.emergency_cases FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for emergency_cases" ON public.emergency_cases;
CREATE POLICY "Allow public delete for emergency_cases" ON public.emergency_cases FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 13. ICU Beds Table
CREATE TABLE IF NOT EXISTS public.icu_beds (
  id TEXT PRIMARY KEY,
  patient_name TEXT,
  mrn TEXT,
  status TEXT DEFAULT 'Available',
  primary_doc TEXT,
  admitted_date DATE,
  gender TEXT,
  age INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.icu_beds ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read for icu_beds" ON public.icu_beds;
CREATE POLICY "Allow public read for icu_beds" ON public.icu_beds FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for icu_beds" ON public.icu_beds;
CREATE POLICY "Allow public insert for icu_beds" ON public.icu_beds FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for icu_beds" ON public.icu_beds;
CREATE POLICY "Allow public update for icu_beds" ON public.icu_beds FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for icu_beds" ON public.icu_beds;
CREATE POLICY "Allow public delete for icu_beds" ON public.icu_beds FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 14. ICU Patient Vitals Table
CREATE TABLE IF NOT EXISTS public.icu_vitals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bed_id TEXT REFERENCES public.icu_beds(id) ON DELETE CASCADE,
  heart_rate INTEGER,
  bp TEXT,
  spo2 INTEGER,
  resp_rate INTEGER,
  temp DECIMAL(4,1),
  recorded_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.icu_vitals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read for icu_vitals" ON public.icu_vitals;
CREATE POLICY "Allow public read for icu_vitals" ON public.icu_vitals FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for icu_vitals" ON public.icu_vitals;
CREATE POLICY "Allow public insert for icu_vitals" ON public.icu_vitals FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for icu_vitals" ON public.icu_vitals;
CREATE POLICY "Allow public update for icu_vitals" ON public.icu_vitals FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for icu_vitals" ON public.icu_vitals;
CREATE POLICY "Allow public delete for icu_vitals" ON public.icu_vitals FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 15. ICU Ventilators Table
CREATE TABLE IF NOT EXISTS public.icu_ventilators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bed_id TEXT REFERENCES public.icu_beds(id) ON DELETE CASCADE UNIQUE,
  mode TEXT,
  fio2 INTEGER,
  peep INTEGER,
  tidal_volume INTEGER,
  respiratory_rate INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.icu_ventilators ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read for icu_ventilators" ON public.icu_ventilators;
CREATE POLICY "Allow public read for icu_ventilators" ON public.icu_ventilators FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for icu_ventilators" ON public.icu_ventilators;
CREATE POLICY "Allow public insert for icu_ventilators" ON public.icu_ventilators FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for icu_ventilators" ON public.icu_ventilators;
CREATE POLICY "Allow public update for icu_ventilators" ON public.icu_ventilators FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for icu_ventilators" ON public.icu_ventilators;
CREATE POLICY "Allow public delete for icu_ventilators" ON public.icu_ventilators FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 16. ICU Infusions Table
CREATE TABLE IF NOT EXISTS public.icu_infusions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bed_id TEXT REFERENCES public.icu_beds(id) ON DELETE CASCADE,
  drug_name TEXT,
  rate TEXT,
  concentration TEXT,
  remarks TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.icu_infusions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read for icu_infusions" ON public.icu_infusions;
CREATE POLICY "Allow public read for icu_infusions" ON public.icu_infusions FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for icu_infusions" ON public.icu_infusions;
CREATE POLICY "Allow public insert for icu_infusions" ON public.icu_infusions FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for icu_infusions" ON public.icu_infusions;
CREATE POLICY "Allow public update for icu_infusions" ON public.icu_infusions FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for icu_infusions" ON public.icu_infusions;
CREATE POLICY "Allow public delete for icu_infusions" ON public.icu_infusions FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 17. ICU Alerts / Incidents Table
CREATE TABLE IF NOT EXISTS public.icu_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bed_id TEXT REFERENCES public.icu_beds(id) ON DELETE CASCADE,
  event_name TEXT NOT NULL,
  severity TEXT NOT NULL,
  action_taken TEXT NOT NULL,
  logged_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.icu_alerts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read for icu_alerts" ON public.icu_alerts;
CREATE POLICY "Allow public read for icu_alerts" ON public.icu_alerts FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for icu_alerts" ON public.icu_alerts;
CREATE POLICY "Allow public insert for icu_alerts" ON public.icu_alerts FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for icu_alerts" ON public.icu_alerts;
CREATE POLICY "Allow public update for icu_alerts" ON public.icu_alerts FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for icu_alerts" ON public.icu_alerts;
CREATE POLICY "Allow public delete for icu_alerts" ON public.icu_alerts FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 18. Hospital Inventory & Purchasing System
CREATE TABLE IF NOT EXISTS public.hospital_inventory_items (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT,
  stock INTEGER DEFAULT 0,
  unit TEXT,
  min_level INTEGER DEFAULT 10,
  unit_cost DECIMAL(10, 2),
  location TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.hospital_inventory_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for hospital_inventory_items" ON public.hospital_inventory_items;
CREATE POLICY "Allow public read for hospital_inventory_items" ON public.hospital_inventory_items FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for hospital_inventory_items" ON public.hospital_inventory_items;
CREATE POLICY "Allow public insert for hospital_inventory_items" ON public.hospital_inventory_items FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for hospital_inventory_items" ON public.hospital_inventory_items;
CREATE POLICY "Allow public update for hospital_inventory_items" ON public.hospital_inventory_items FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for hospital_inventory_items" ON public.hospital_inventory_items;
CREATE POLICY "Allow public delete for hospital_inventory_items" ON public.hospital_inventory_items FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

CREATE TABLE IF NOT EXISTS public.hospital_purchase_orders (
  po_number TEXT PRIMARY KEY,
  vendor TEXT NOT NULL,
  item TEXT NOT NULL,
  order_qty INTEGER NOT NULL,
  cost DECIMAL(10, 2),
  date DATE,
  status TEXT DEFAULT 'Draft',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.hospital_purchase_orders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for hospital_purchase_orders" ON public.hospital_purchase_orders;
CREATE POLICY "Allow public read for hospital_purchase_orders" ON public.hospital_purchase_orders FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for hospital_purchase_orders" ON public.hospital_purchase_orders;
CREATE POLICY "Allow public insert for hospital_purchase_orders" ON public.hospital_purchase_orders FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for hospital_purchase_orders" ON public.hospital_purchase_orders;
CREATE POLICY "Allow public update for hospital_purchase_orders" ON public.hospital_purchase_orders FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for hospital_purchase_orders" ON public.hospital_purchase_orders;
CREATE POLICY "Allow public delete for hospital_purchase_orders" ON public.hospital_purchase_orders FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

CREATE TABLE IF NOT EXISTS public.hospital_goods_receipts (
  grn_number TEXT PRIMARY KEY,
  po_number TEXT REFERENCES public.hospital_purchase_orders(po_number) ON DELETE SET NULL,
  item TEXT NOT NULL,
  received_qty INTEGER NOT NULL,
  supplier TEXT NOT NULL,
  batch_no TEXT NOT NULL,
  expiry DATE,
  date DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.hospital_goods_receipts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for hospital_goods_receipts" ON public.hospital_goods_receipts;
CREATE POLICY "Allow public read for hospital_goods_receipts" ON public.hospital_goods_receipts FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for hospital_goods_receipts" ON public.hospital_goods_receipts;
CREATE POLICY "Allow public insert for hospital_goods_receipts" ON public.hospital_goods_receipts FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for hospital_goods_receipts" ON public.hospital_goods_receipts;
CREATE POLICY "Allow public update for hospital_goods_receipts" ON public.hospital_goods_receipts FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for hospital_goods_receipts" ON public.hospital_goods_receipts;
CREATE POLICY "Allow public delete for hospital_goods_receipts" ON public.hospital_goods_receipts FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

CREATE TABLE IF NOT EXISTS public.hospital_inventory_transfers (
  id TEXT PRIMARY KEY,
  item TEXT NOT NULL,
  qty INTEGER NOT NULL,
  from_location TEXT NOT NULL,
  to_location TEXT NOT NULL,
  date DATE,
  status TEXT DEFAULT 'Completed',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.hospital_inventory_transfers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for hospital_inventory_transfers" ON public.hospital_inventory_transfers;
CREATE POLICY "Allow public read for hospital_inventory_transfers" ON public.hospital_inventory_transfers FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for hospital_inventory_transfers" ON public.hospital_inventory_transfers;
CREATE POLICY "Allow public insert for hospital_inventory_transfers" ON public.hospital_inventory_transfers FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for hospital_inventory_transfers" ON public.hospital_inventory_transfers;
CREATE POLICY "Allow public update for hospital_inventory_transfers" ON public.hospital_inventory_transfers FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for hospital_inventory_transfers" ON public.hospital_inventory_transfers;
CREATE POLICY "Allow public delete for hospital_inventory_transfers" ON public.hospital_inventory_transfers FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

CREATE TABLE IF NOT EXISTS public.hospital_inventory_consumptions (
  id TEXT PRIMARY KEY,
  item TEXT NOT NULL,
  qty INTEGER NOT NULL,
  mrn TEXT,
  ward TEXT,
  date DATE,
  staff TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.hospital_inventory_consumptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions;
CREATE POLICY "Allow public read for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions;
CREATE POLICY "Allow public insert for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions;
CREATE POLICY "Allow public update for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions;
CREATE POLICY "Allow public delete for hospital_inventory_consumptions" ON public.hospital_inventory_consumptions FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

CREATE TABLE IF NOT EXISTS public.hospital_vendors (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  contact TEXT,
  email TEXT,
  status TEXT DEFAULT 'Active',
  rating TEXT,
  address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.hospital_vendors ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for hospital_vendors" ON public.hospital_vendors;
CREATE POLICY "Allow public read for hospital_vendors" ON public.hospital_vendors FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for hospital_vendors" ON public.hospital_vendors;
CREATE POLICY "Allow public insert for hospital_vendors" ON public.hospital_vendors FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for hospital_vendors" ON public.hospital_vendors;
CREATE POLICY "Allow public update for hospital_vendors" ON public.hospital_vendors FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for hospital_vendors" ON public.hospital_vendors;
CREATE POLICY "Allow public delete for hospital_vendors" ON public.hospital_vendors FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- OT Inventory Table
CREATE TABLE IF NOT EXISTS public.ot_inventory (
  id TEXT PRIMARY KEY,
  code TEXT,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  stock INTEGER NOT NULL,
  unit TEXT NOT NULL,
  min_stock_level INTEGER NOT NULL,
  mrp NUMERIC,
  purchase_price NUMERIC,
  batch_number TEXT,
  expiry_date TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.ot_inventory ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for ot_inventory" ON public.ot_inventory;
CREATE POLICY "Allow public read for ot_inventory" ON public.ot_inventory FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for ot_inventory" ON public.ot_inventory;
CREATE POLICY "Allow public insert for ot_inventory" ON public.ot_inventory FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for ot_inventory" ON public.ot_inventory;
CREATE POLICY "Allow public update for ot_inventory" ON public.ot_inventory FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for ot_inventory" ON public.ot_inventory;
CREATE POLICY "Allow public delete for ot_inventory" ON public.ot_inventory FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- OT Consents Table
CREATE TABLE IF NOT EXISTS public.ot_consents (
  id TEXT PRIMARY KEY,
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  terms TEXT NOT NULL,
  patient_name TEXT NOT NULL,
  guardian_name TEXT,
  witness_name TEXT NOT NULL,
  signed_at TIMESTAMPTZ DEFAULT NOW(),
  signature_type TEXT NOT NULL,
  signature_data TEXT NOT NULL,
  status TEXT DEFAULT 'Signed'
);

ALTER TABLE public.ot_consents ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for ot_consents" ON public.ot_consents;
CREATE POLICY "Allow public read for ot_consents" ON public.ot_consents FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for ot_consents" ON public.ot_consents;
CREATE POLICY "Allow public insert for ot_consents" ON public.ot_consents FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for ot_consents" ON public.ot_consents;
CREATE POLICY "Allow public update for ot_consents" ON public.ot_consents FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for ot_consents" ON public.ot_consents;
CREATE POLICY "Allow public delete for ot_consents" ON public.ot_consents FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- OT Infection Logs Table
CREATE TABLE IF NOT EXISTS public.ot_infection_logs (
  id TEXT PRIMARY KEY,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  theatre_id UUID REFERENCES public.ot_rooms(id) ON DELETE SET NULL,
  theatre_name TEXT,
  cleaning_type TEXT NOT NULL,
  disinfectants_used TEXT NOT NULL,
  air_particle_count TEXT,
  culture_swab_result TEXT NOT NULL,
  logged_by TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.ot_infection_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for ot_infection_logs" ON public.ot_infection_logs;
CREATE POLICY "Allow public read for ot_infection_logs" ON public.ot_infection_logs FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for ot_infection_logs" ON public.ot_infection_logs;
CREATE POLICY "Allow public insert for ot_infection_logs" ON public.ot_infection_logs FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for ot_infection_logs" ON public.ot_infection_logs;
CREATE POLICY "Allow public update for ot_infection_logs" ON public.ot_infection_logs FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for ot_infection_logs" ON public.ot_infection_logs;
CREATE POLICY "Allow public delete for ot_infection_logs" ON public.ot_infection_logs FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 25. Nursing Updates and Assignments
CREATE TABLE IF NOT EXISTS public.nursing_patient_updates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  nurse_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  nurse_name TEXT NOT NULL,
  note TEXT NOT NULL,
  alert_level TEXT DEFAULT 'Normal' CHECK (alert_level IN ('Normal', 'Moderate Alert', 'Critical Alert')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.nursing_patient_updates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for nursing_patient_updates" ON public.nursing_patient_updates;
CREATE POLICY "Allow public read for nursing_patient_updates" ON public.nursing_patient_updates FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for nursing_patient_updates" ON public.nursing_patient_updates;
CREATE POLICY "Allow public insert for nursing_patient_updates" ON public.nursing_patient_updates FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for nursing_patient_updates" ON public.nursing_patient_updates;
CREATE POLICY "Allow public delete for nursing_patient_updates" ON public.nursing_patient_updates FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- Alter patients and admissions to add assigned nurse details for nursing roster assignments
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS assigned_nurse_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS assigned_nurse_name TEXT;

ALTER TABLE public.admissions ADD COLUMN IF NOT EXISTS assigned_nurse_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
ALTER TABLE public.admissions ADD COLUMN IF NOT EXISTS assigned_nurse_name TEXT;

-- 26. Hospital Tax, GST, Pharmacy HSN & Diagnostic LIS Migrations
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS taxable_amount DECIMAL(12, 2) DEFAULT 0.00;
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS cgst_amount DECIMAL(12, 2) DEFAULT 0.00;
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS sgst_amount DECIMAL(12, 2) DEFAULT 0.00;
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS tax_amount DECIMAL(12, 2) DEFAULT 0.00;
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS hospital_gstin TEXT;

ALTER TABLE public.invoice_items ADD COLUMN IF NOT EXISTS tax_percentage DECIMAL(5, 2) DEFAULT 0.00;
ALTER TABLE public.invoice_items ADD COLUMN IF NOT EXISTS cgst_amount DECIMAL(12, 2) DEFAULT 0.00;
ALTER TABLE public.invoice_items ADD COLUMN IF NOT EXISTS sgst_amount DECIMAL(12, 2) DEFAULT 0.00;
ALTER TABLE public.invoice_items ADD COLUMN IF NOT EXISTS hsn_code TEXT;

ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS tax_percentage DECIMAL(5, 2) DEFAULT 12.00;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS hsn_code TEXT DEFAULT '3004';
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS units_per_strip INT DEFAULT 10;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS loose_selling_price DECIMAL(10, 2) DEFAULT 0.00;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS loose_stock INT DEFAULT 0;
ALTER TABLE public.pharmacy_items ADD COLUMN IF NOT EXISTS is_loose_sale_enabled BOOLEAN DEFAULT true;

ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS test_name TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS reference_range TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS unit TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS urgency TEXT DEFAULT 'routine';
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS result_value TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS clinical_notes TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS findings TEXT;
ALTER TABLE public.test_requests ADD COLUMN IF NOT EXISTS sample_id TEXT;

ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS type TEXT DEFAULT 'OPD';
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS department TEXT;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS urgency TEXT DEFAULT 'routine';
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS patient_name TEXT;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS appointment_time TEXT;

-- Tax Slabs Master Table (if not existing)
CREATE TABLE IF NOT EXISTS public.tax_slabs (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name TEXT NOT NULL,
  rate DECIMAL(5, 2) NOT NULL DEFAULT 0.00,
  type TEXT DEFAULT 'Percentage',
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.tax_slabs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read for tax_slabs" ON public.tax_slabs;
CREATE POLICY "Allow public read for tax_slabs" ON public.tax_slabs FOR SELECT USING (true);
DROP POLICY IF EXISTS "Allow public insert for tax_slabs" ON public.tax_slabs;
CREATE POLICY "Allow public insert for tax_slabs" ON public.tax_slabs FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public update for tax_slabs" ON public.tax_slabs;
CREATE POLICY "Allow public update for tax_slabs" ON public.tax_slabs FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);
DROP POLICY IF EXISTS "Allow public delete for tax_slabs" ON public.tax_slabs;
CREATE POLICY "Allow public delete for tax_slabs" ON public.tax_slabs FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '') IS NOT NULL);

-- 27. Enable Supabase Realtime across all devices & Vercel
DO $$
DECLARE
    tbl text;
    tables text[] := ARRAY[
        'profiles', 'patients', 'appointments', 'admissions', 'beds', 
        'patient_vitals', 'prescriptions', 'prescription_medicines', 'test_requests', 
        'invoices', 'invoice_items', 'payments', 'expenses', 'pharmacy_items', 
        'pharmacy_sales', 'pharmacy_sale_items', 'insurance_claims', 'ot_schedules', 
        'ot_consent_forms', 'ot_surgery_consent_forms', 'ot_biopsy_forms', 
        'ot_clinical_records', 'ot_pharmacy_requisitions', 'ot_surgical_safety_checklists', 
        'ot_anaesthesia_records', 'anaesthetic_operation_records', 'carewell_preop_orders', 
        'carewell_ot_summary_forms', 'nursing_notes', 'hourly_vitals', 
        'ipd_initial_evaluation_sheets', 'endoscopy_direct_procedures', 
        'endoscopy_scope_disinfection_logs', 'endoscopy_safety_checklists', 
        'visiting_specialists', 'visiting_consultations', 'central_counter_payments', 
        'medical_equipment', 'equipment_breakdowns', 'hospital_info', 'tax_slabs',
        'special_grbs_charts', 'special_io_charts', 'special_drain_charts', 
        'special_endo_recovery_charts', 'emergency_resuscitation_logs', 'bed_transfers', 
        'clinical_procedure_rates', 'cardiology_equipment_rates', 'endo_procedure_rates', 
        'gastro_services_rates', 'hospital_room_rates'
    ];
BEGIN
    -- Ensure publication exists
    IF NOT EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
        CREATE PUBLICATION supabase_realtime;
    END IF;

    -- Add each existing table to supabase_realtime publication
    FOREACH tbl IN ARRAY tables
    LOOP
        IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = tbl) THEN
            BEGIN
                EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', tbl);
            EXCEPTION WHEN duplicate_object THEN
                NULL;
            END;
        END IF;
    END LOOP;
END $$;

-- ==============================================================================
-- HOSPITAL MANAGEMENT SYSTEM - EXTENDED RELATIONAL SCHEMA
-- ==============================================================================

-- 1. IPD Special Clinical Charts (GRBS, Fluid I/O, Drains, Endoscopy Recovery)
CREATE TABLE IF NOT EXISTS public.special_grbs_charts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT,
  bed_number TEXT,
  monitoring_slot TEXT DEFAULT 'Pre-Lunch',
  grbs_value INTEGER NOT NULL,
  sliding_scale_units INTEGER DEFAULT 0,
  insulin_type_route TEXT,
  urine_ketones TEXT DEFAULT 'Negative',
  hypoglycemia_symptoms TEXT DEFAULT 'None',
  doctor_instructions TEXT,
  recorded_by TEXT,
  recorded_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.special_io_charts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT,
  bed_number TEXT,
  shift TEXT DEFAULT 'Morning (8am-2pm)',
  oral_water_ml INTEGER DEFAULT 0,
  iv_drips_ml INTEGER DEFAULT 0,
  tube_feed_ml INTEGER DEFAULT 0,
  blood_pcv_ml INTEGER DEFAULT 0,
  urine_output_ml INTEGER DEFAULT 0,
  ng_aspirate_ml INTEGER DEFAULT 0,
  drains_total_ml INTEGER DEFAULT 0,
  vomit_stool_ml INTEGER DEFAULT 0,
  nursing_remarks TEXT,
  recorded_by TEXT,
  recorded_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.special_drain_charts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT,
  bed_number TEXT,
  drain_name_type TEXT NOT NULL,
  anatomical_site TEXT,
  volume_output_ml INTEGER DEFAULT 0,
  color_aspect TEXT DEFAULT 'Serosanguineous',
  doctor_instructions TEXT,
  nursing_site_remarks TEXT,
  recorded_by TEXT,
  recorded_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.special_endo_recovery_charts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT,
  bed_number TEXT,
  procedure_type TEXT DEFAULT 'Upper GI Endoscopy',
  bowel_prep_status TEXT DEFAULT 'Clear Yellow Liquid Stool',
  bp TEXT,
  pulse TEXT,
  spo2 TEXT,
  temp TEXT,
  abdominal_assessment TEXT DEFAULT 'Soft non-tender',
  diet_progression_order TEXT DEFAULT 'Sips of Water',
  biopsy_taken BOOLEAN DEFAULT FALSE,
  biopsy_details TEXT,
  doctor_recovery_instructions TEXT,
  recorded_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Carewell Operation Theatre Documentation
CREATE TABLE IF NOT EXISTS public.carewell_preop_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_ref_no TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES public.patients(id) ON DELETE SET NULL,
  patient_name TEXT NOT NULL,
  age_sex TEXT,
  ipd_no TEXT,
  hospital_no TEXT,
  surgery_name TEXT NOT NULL,
  anesthesia_type TEXT DEFAULT 'GA',
  order_date DATE DEFAULT CURRENT_DATE,
  npo_status TEXT DEFAULT 'Nil orally after midnight',
  diet_instructions TEXT DEFAULT 'Clear fluids till midnight',
  written_consent_verified BOOLEAN DEFAULT TRUE,
  skin_prep_instructions TEXT DEFAULT 'Abdominal skin prep with Savlon',
  pac_orders_followed BOOLEAN DEFAULT TRUE,
  morning_bath_instructions TEXT DEFAULT 'Morning Bath at 7.00 am with Savlon Soap',
  xylocaine_sensitivity TEXT DEFAULT 'Non-Sensitive',
  premedication_tablets JSONB DEFAULT '[]'::jsonb,
  iv_injections_antibiotics JSONB DEFAULT '[]'::jsonb,
  iv_fluids_orders JSONB DEFAULT '[]'::jsonb,
  blood_arrangements TEXT,
  special_directives TEXT,
  prescribed_by_doctor TEXT,
  nursing_execution_status TEXT DEFAULT 'Executed',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.carewell_ot_summary_forms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sheet_code TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES public.patients(id) ON DELETE SET NULL,
  patient_name TEXT NOT NULL,
  ipd_no TEXT,
  bed_no TEXT,
  surgeon_name TEXT,
  anesthetist_name TEXT,
  date_of_surgery DATE DEFAULT CURRENT_DATE,
  checklist_items JSONB DEFAULT '{"npo": true, "consent": true, "skinPrep": true, "vitalsChecked": true, "pacCleared": true, "denturesRemoved": true, "jewelleryRemoved": true, "voidedUrinated": true, "premedicationGiven": true, "bloodArranged": true}'::jsonb,
  doctor_signatures_status TEXT DEFAULT 'SIGNED',
  nursing_checklist_verifier TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Endoscopy Direct Registration, Safety & Disinfection
CREATE TABLE IF NOT EXISTS public.endoscopy_direct_procedures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  procedure_name TEXT NOT NULL,
  procedure_category TEXT DEFAULT 'GI Procedure',
  department_id UUID REFERENCES public.departments(id) ON DELETE SET NULL,
  doctor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  doctor_name TEXT,
  procedure_cost NUMERIC(12,2) DEFAULT 0.00,
  invoice_id UUID REFERENCES public.invoices(id) ON DELETE SET NULL,
  payment_status TEXT DEFAULT 'Paid',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.endoscopy_safety_checklists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  procedure_name TEXT NOT NULL,
  consent_verified BOOLEAN DEFAULT TRUE,
  dentures_removed BOOLEAN DEFAULT TRUE,
  fasting_confirmed BOOLEAN DEFAULT TRUE,
  throat_spray_given BOOLEAN DEFAULT FALSE,
  monitoring_attached BOOLEAN DEFAULT TRUE,
  oxygen_supplemented BOOLEAN DEFAULT FALSE,
  verified_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.endoscopy_scope_disinfection_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scope_serial_number TEXT NOT NULL,
  scope_model TEXT NOT NULL,
  disinfectant_chemical TEXT DEFAULT 'Cidex OPA / Ortho-phthalaldehyde',
  leak_test_passed BOOLEAN DEFAULT TRUE,
  cleaning_time_minutes INTEGER DEFAULT 20,
  rinse_completed BOOLEAN DEFAULT TRUE,
  logged_by TEXT NOT NULL,
  log_timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Centralized Counter Payments
CREATE TABLE IF NOT EXISTS public.central_counter_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_no TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES public.patients(id) ON DELETE SET NULL,
  patient_name TEXT NOT NULL,
  patient_mrn TEXT,
  patient_phone TEXT,
  payment_date TIMESTAMPTZ DEFAULT NOW(),
  amount DECIMAL(12,2) DEFAULT 0.00,
  discount_amount DECIMAL(12,2) DEFAULT 0.00,
  discount_reason TEXT,
  payment_mode TEXT NOT NULL DEFAULT 'Cash',
  transaction_ref TEXT,
  bank_name TEXT,
  payer_name TEXT,
  remarks TEXT,
  settled_invoices JSONB DEFAULT '[]'::jsonb,
  collected_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Visiting Specialists / Consultants Directory & Consultations
CREATE TABLE IF NOT EXISTS public.visiting_specialists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_name TEXT NOT NULL,
  specialty TEXT NOT NULL,
  qualification TEXT,
  phone_number TEXT NOT NULL,
  default_fee DECIMAL(10,2) DEFAULT 1500.00,
  hospital_affiliation TEXT,
  visiting_schedule TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.visiting_consultations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  uhid_mrn TEXT,
  ipd_number TEXT,
  ward_bed_no TEXT,
  consultation_date DATE DEFAULT CURRENT_DATE,
  consultation_time TEXT,
  consultation_type TEXT DEFAULT 'Cross-Consultation',
  visit_charges DECIMAL(10,2) DEFAULT 1500.00,
  bp TEXT,
  pulse TEXT,
  temp TEXT,
  spo2 TEXT,
  rr TEXT,
  reason_for_call TEXT,
  examination_findings TEXT,
  impression_diagnosis TEXT,
  detailed_orders_instructions TEXT,
  prescribed_dose TEXT,
  prescribed_frequency TEXT,
  prescribed_duration TEXT,
  recommended_investigations TEXT,
  specialist_id UUID REFERENCES public.visiting_specialists(id) ON DELETE SET NULL,
  specialist_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Emergency Resuscitation & Rapid Response Code Logs
CREATE TABLE IF NOT EXISTS public.emergency_resuscitation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  emergency_case_id UUID REFERENCES public.emergency_cases(id) ON DELETE CASCADE,
  patient_id UUID REFERENCES public.patients(id) ON DELETE SET NULL,
  code_start_time TIMESTAMPTZ DEFAULT NOW(),
  initial_rhythm TEXT DEFAULT 'PEA',
  cpr_cycles_performed INTEGER DEFAULT 0,
  shocks_delivered INTEGER DEFAULT 0,
  epinephrine_doses_given INTEGER DEFAULT 0,
  amiodarone_doses_given INTEGER DEFAULT 0,
  intubation_status TEXT DEFAULT 'Endotracheal Tube Placed',
  rosc_achieved BOOLEAN DEFAULT FALSE,
  rosc_time TIMESTAMPTZ,
  team_leader TEXT,
  recorded_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Inpatient Bed Transfers Audit Log
CREATE TABLE IF NOT EXISTS public.bed_transfers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  from_bed_id UUID REFERENCES public.beds(id) ON DELETE SET NULL,
  to_bed_id UUID NOT NULL REFERENCES public.beds(id) ON DELETE CASCADE,
  from_ward TEXT,
  to_ward TEXT,
  reason TEXT,
  transferred_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  transfer_date TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Pharmacy POS & Over-The-Counter Sales
CREATE TABLE IF NOT EXISTS public.pharmacy_sales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES public.patients(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  doctor_name TEXT,
  subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  discount_amount DECIMAL(10,2) DEFAULT 0.00,
  tax_amount DECIMAL(10,2) DEFAULT 0.00,
  total_amount DECIMAL(10,2) NOT NULL,
  payment_mode TEXT DEFAULT 'Cash',
  payment_status TEXT DEFAULT 'Paid',
  dispensed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.pharmacy_sale_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id UUID NOT NULL REFERENCES public.pharmacy_sales(id) ON DELETE CASCADE,
  item_id UUID REFERENCES public.pharmacy_items(id) ON DELETE SET NULL,
  item_name TEXT NOT NULL,
  batch_number TEXT,
  expiry_date DATE,
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  tax_percentage DECIMAL(5,2) DEFAULT 0.00
);

-- 9. Clinical & Procedure Tariff Master Rates
CREATE TABLE IF NOT EXISTS public.clinical_procedure_rates (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  category TEXT DEFAULT 'Clinical',
  rate NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  description TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.cardiology_equipment_rates (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  rate NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.endo_procedure_rates (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  rate NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.gastro_services_rates (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  rate NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.hospital_room_rates (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  ward_type TEXT UNIQUE NOT NULL,
  daily_charge NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  nursing_charge NUMERIC(12,2) DEFAULT 0.00,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- AUTOMATIC ROW LEVEL SECURITY (RLS) POLICIES & SUPABASE REALTIME REGISTRATION
-- ==============================================================================
DO $$
DECLARE
    r RECORD;
    tables text[] := ARRAY[
      'special_grbs_charts', 'special_io_charts', 'special_drain_charts', 
      'special_endo_recovery_charts', 'carewell_preop_orders', 
      'carewell_ot_summary_forms', 'endoscopy_direct_procedures', 
      'endoscopy_safety_checklists', 'endoscopy_scope_disinfection_logs', 
      'central_counter_payments', 'visiting_specialists', 'visiting_consultations', 
      'emergency_resuscitation_logs', 'bed_transfers', 'pharmacy_sales', 
      'pharmacy_sale_items', 'clinical_procedure_rates', 'cardiology_equipment_rates', 
      'endo_procedure_rates', 'gastro_services_rates', 'hospital_room_rates'
    ];
    tbl text;
BEGIN
    FOR r IN (
        SELECT tablename
        FROM pg_tables
        WHERE schemaname = 'public' AND tablename = ANY(tables)
    )
    LOOP
        EXECUTE 'ALTER TABLE public.' || quote_ident(r.tablename) || ' ENABLE ROW LEVEL SECURITY;';
        EXECUTE 'DROP POLICY IF EXISTS "Allow public read" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Allow public insert" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Allow public update" ON public.' || quote_ident(r.tablename);
        EXECUTE 'DROP POLICY IF EXISTS "Allow public delete" ON public.' || quote_ident(r.tablename);

        EXECUTE 'CREATE POLICY "Allow public read" ON public.' || quote_ident(r.tablename) || ' FOR SELECT TO authenticated, anon USING (true);';
        EXECUTE 'CREATE POLICY "Allow public insert" ON public.' || quote_ident(r.tablename) || ' FOR INSERT TO authenticated, anon WITH CHECK (coalesce(auth.role(), '''') IS NOT NULL);';
        EXECUTE 'CREATE POLICY "Allow public update" ON public.' || quote_ident(r.tablename) || ' FOR UPDATE TO authenticated, anon USING (coalesce(auth.role(), '''') IS NOT NULL) WITH CHECK (coalesce(auth.role(), '''') IS NOT NULL);';
        EXECUTE 'CREATE POLICY "Allow public delete" ON public.' || quote_ident(r.tablename) || ' FOR DELETE TO authenticated, anon USING (coalesce(auth.role(), '''') IS NOT NULL);';
    END LOOP;

    -- Register with Supabase Realtime Publication
    IF NOT EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
        CREATE PUBLICATION supabase_realtime;
    END IF;

    FOREACH tbl IN ARRAY tables
    LOOP
        IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = tbl) THEN
            BEGIN
                EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', tbl);
            EXCEPTION WHEN duplicate_object THEN
                NULL;
            END;
        END IF;
    END LOOP;
END $$;

-- REFRESH SCHEMA CACHE FOR POSTGREST (SUPER IMPORTANT AFTER EXECUTING ALTER STATEMENTS)
NOTIFY pgrst, 'reload schema';


